#!/usr/bin/env python3
"""
Automatic retraining helper for the Solar Tracker AI project.

What it does:
  1) Downloads the real CSV log from the SensorHub ESP32 dashboard (/download).
  2) Merges it with the original Excel training file, if provided.
  3) Retrains the same Ridge + daily-profile model.
  4) Generates SolarAI_Model.generated.h and ai_model_metrics.json.
  5) Optionally patches SensorHub_AI_Forecast_Professional_Dashboard.ino with the new arrays.

Examples:
  python auto_retrain_from_esp32.py --esp32 http://192.168.1.50 --base-excel training_data.xlsx
  python auto_retrain_from_esp32.py --esp32 http://192.168.1.50 --patch-sketch SensorHub_AI_Forecast_Professional_Dashboard.ino

Recommended automation:
  Run this script daily from a Raspberry Pi / laptop / mini PC using cron or Task Scheduler.
  Full model training is intentionally kept off the ESP32; the ESP32 is best for sensing,
  prediction and dashboard display, not for running pandas/sklearn training.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Iterable
from urllib.request import urlopen

import numpy as np
import pandas as pd
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

REQUIRED_COLUMNS = [
    "timestamp_iso", "date_yyyy_mm_dd", "hour_decimal",
    "ambient_temp_c", "ambient_humidity_pct", "panel_temp_est_c",
    "irradiance_est_w_m2", "light_avg_pct", "rain_wet_pct", "rain_digital_wet",
    "dust_est_ug_m3", "solar_bus_v", "solar_current_a", "solar_power_w",
]


def read_excel_or_none(path: Path | None) -> pd.DataFrame:
    if not path or not path.exists():
        return pd.DataFrame()
    return pd.read_excel(path, sheet_name="Readings_Month")


def download_esp32_csv(base_url: str, timeout: int = 25) -> pd.DataFrame:
    url = base_url.rstrip("/") + "/download"
    with urlopen(url, timeout=timeout) as resp:
        raw = resp.read()
    if not raw.strip():
        return pd.DataFrame()
    from io import BytesIO
    return pd.read_csv(BytesIO(raw))


def read_csv_or_none(path: Path | None) -> pd.DataFrame:
    if not path or not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)


def clean_training_frame(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    # Remove accidental repeated headers inside logs.
    df = df[df.get("timestamp_iso", "") != "timestamp_iso"].copy()
    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            df[col] = np.nan

    # Keep only rows with real time. Uptime rows cannot teach tomorrow/hour-of-day patterns reliably.
    df["timestamp"] = pd.to_datetime(df["timestamp_iso"], errors="coerce")
    df = df[df["timestamp"].notna()].copy()
    if "time_synced" in df.columns:
        df = df[pd.to_numeric(df["time_synced"], errors="coerce").fillna(1).astype(int) == 1]

    numeric_cols = [c for c in REQUIRED_COLUMNS if c not in ("timestamp_iso", "date_yyyy_mm_dd")]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Only train on sensor-valid rows when flags are available.
    if "dht22_ok" in df.columns:
        df = df[pd.to_numeric(df["dht22_ok"], errors="coerce").fillna(1).astype(int) == 1]
    if "ina226_ok" in df.columns:
        df = df[pd.to_numeric(df["ina226_ok"], errors="coerce").fillna(1).astype(int) == 1]
    if "adc_extreme" in df.columns:
        df = df[pd.to_numeric(df["adc_extreme"], errors="coerce").fillna(0).astype(int) == 0]

    df = df.dropna(subset=[
        "hour_decimal", "ambient_temp_c", "ambient_humidity_pct", "panel_temp_est_c",
        "irradiance_est_w_m2", "light_avg_pct", "dust_est_ug_m3", "solar_power_w",
    ])
    df["date_yyyy_mm_dd"] = df["timestamp"].dt.strftime("%Y-%m-%d")
    df["slot"] = np.clip(np.floor(df["hour_decimal"].astype(float) * 4 + 1e-6).astype(int), 0, 95)
    return df.sort_values("timestamp").drop_duplicates(subset=["timestamp_iso"], keep="last").reset_index(drop=True)


def make_power_features(data: pd.DataFrame) -> pd.DataFrame:
    h = data["hour_decimal"].astype(float).values
    irr = data["irradiance_est_w_m2"].astype(float).values
    return pd.DataFrame({
        "h_sin": np.sin(2 * np.pi * h / 24),
        "h_cos": np.cos(2 * np.pi * h / 24),
        "h2_sin": np.sin(4 * np.pi * h / 24),
        "h2_cos": np.cos(4 * np.pi * h / 24),
        "irradiance": irr,
        "irradiance2": (irr / 1000.0) ** 2,
        "ambient": data["ambient_temp_c"].astype(float).values,
        "humidity": data["ambient_humidity_pct"].astype(float).values,
        "panel": data["panel_temp_est_c"].astype(float).values,
        "dust": data["dust_est_ug_m3"].astype(float).values,
        "rain_pct": data["rain_wet_pct"].astype(float).fillna(0).values,
        "rain_wet": data["rain_digital_wet"].astype(float).fillna(0).values,
        "light_pct": data["light_avg_pct"].astype(float).values,
    })


def cfloat(v: float, digits: int = 8) -> str:
    s = f"{float(v):.{digits}g}"
    if "nan" in s.lower() or "inf" in s.lower():
        s = "0.0"
    if "." not in s and "e" not in s and "E" not in s:
        s += ".0"
    return s + "f"


def fmt_arr(vals: Iterable[float], per_line: int = 8, digits: int = 8) -> str:
    vals = list(vals)
    lines = []
    for i in range(0, len(vals), per_line):
        lines.append("  " + ", ".join(cfloat(v, digits) for v in vals[i:i + per_line]))
    return ",\n".join(lines)


def model_dict(pipe, names: list[str]) -> dict:
    scaler = pipe.named_steps["standardscaler"]
    ridge = pipe.named_steps["ridgecv"]
    return {
        "features": names,
        "mean": scaler.mean_.astype(float).tolist(),
        "scale": scaler.scale_.astype(float).tolist(),
        "coef": ridge.coef_.astype(float).tolist(),
        "intercept": float(ridge.intercept_),
        "alpha": float(ridge.alpha_),
    }


def train_model(df: pd.DataFrame, outdir: Path) -> dict:
    if len(df) < 200:
        raise SystemExit(f"Not enough valid rows for retraining: {len(df)}. Collect at least 200 valid rows; 7+ days is better.")

    X = make_power_features(df)
    y = df["solar_power_w"].astype(float).values

    # Chronological holdout: last 20%, but at least 96 rows and at most 5 days when possible.
    n_test = int(max(96, min(len(df) * 0.2, 96 * 5)))
    train_mask = np.zeros(len(df), dtype=bool)
    train_mask[: len(df) - n_test] = True
    if train_mask.sum() < 100 or (~train_mask).sum() < 20:
        raise SystemExit("Not enough train/test rows after split. Collect more valid sensor data.")

    alphas = np.logspace(-4, 4, 30)
    cv = 5 if train_mask.sum() >= 300 else 3
    power_pipe = make_pipeline(StandardScaler(), RidgeCV(alphas=alphas, cv=cv))
    power_pipe.fit(X[train_mask], y[train_mask])
    power_pred = np.clip(power_pipe.predict(X[~train_mask]), 0, 30)

    df2 = df.copy()
    power = df2["solar_power_w"].astype(float).values
    target_next = np.full(len(df2), np.nan)
    for i in range(len(df2) - 4):
        dt = df2["timestamp"].iloc[i + 4] - df2["timestamp"].iloc[i]
        if pd.Timedelta(minutes=55) <= dt <= pd.Timedelta(minutes=65):
            target_next[i] = power[i + 1:i + 5].sum() * 0.25
    df2["target_next_hour_wh"] = target_next
    mask = ~np.isnan(target_next)
    if mask.sum() < 200:
        raise SystemExit("Not enough continuous 15-minute rows to train next-hour model. Keep the logger running longer.")

    Xn = make_power_features(df2.loc[mask]).copy()
    Xn["current_power"] = df2.loc[mask, "solar_power_w"].astype(float).values
    Xn["bus_v"] = df2.loc[mask, "solar_bus_v"].astype(float).values
    Xn["current_a"] = df2.loc[mask, "solar_current_a"].astype(float).values
    yn = df2.loc[mask, "target_next_hour_wh"].astype(float).values

    # Same chronological split applied to the masked next-hour data.
    next_index = np.where(mask.values)[0]
    train_mask_n = next_index < (len(df) - n_test)
    if train_mask_n.sum() < 100 or (~train_mask_n).sum() < 20:
        train_mask_n = np.zeros(len(Xn), dtype=bool)
        train_mask_n[: max(1, len(Xn) - min(n_test, len(Xn) // 5))] = True

    next_pipe = make_pipeline(StandardScaler(), RidgeCV(alphas=alphas, cv=cv))
    next_pipe.fit(Xn[train_mask_n], yn[train_mask_n])
    next_pred = np.clip(next_pipe.predict(Xn[~train_mask_n]), 0, 30)

    profile = df.groupby("slot").agg({
        "irradiance_est_w_m2": "mean",
        "ambient_temp_c": "mean",
        "ambient_humidity_pct": "mean",
    }).reindex(range(96)).interpolate().ffill().bfill()

    power_model = model_dict(power_pipe, list(X.columns))
    next_model = model_dict(next_pipe, list(Xn.columns))
    generated_at = datetime.now().strftime("%Y%m%d_%H%M")
    date_max = str(df["date_yyyy_mm_dd"].max())
    model_name = f"solar_ridge_auto_{date_max.replace('-', '')}_{generated_at}"

    metrics = {
        "model_name": model_name,
        "dataset_rows_valid": int(len(df)),
        "dataset_date_min": str(df["date_yyyy_mm_dd"].min()),
        "dataset_date_max": date_max,
        "test_rows_instant": int((~train_mask).sum()),
        "test_rows_next_hour": int((~train_mask_n).sum()),
        "instant_power": {
            "mae_w": float(mean_absolute_error(y[~train_mask], power_pred)),
            "rmse_w": float(mean_squared_error(y[~train_mask], power_pred) ** 0.5),
            "r2": float(r2_score(y[~train_mask], power_pred)),
            "alpha": power_model["alpha"],
        },
        "next_hour_energy": {
            "mae_wh": float(mean_absolute_error(yn[~train_mask_n], next_pred)),
            "rmse_wh": float(mean_squared_error(yn[~train_mask_n], next_pred) ** 0.5),
            "r2": float(r2_score(yn[~train_mask_n], next_pred)),
            "alpha": next_model["alpha"],
        },
        "features": {
            "instant_power": power_model["features"],
            "next_hour": next_model["features"],
        },
    }

    header = f"""// Auto-generated by auto_retrain_from_esp32.py
// Model name: {model_name}
// Dataset: {metrics['dataset_date_min']} to {metrics['dataset_date_max']} ({metrics['dataset_rows_valid']} valid rows)
static const char* AI_MODEL_NAME = \"{model_name}\";

static const float AI_IRR_PROFILE[AI_SLOT_COUNT] = {{
{fmt_arr(profile['irradiance_est_w_m2'].values)}
}};
static const float AI_AMBIENT_PROFILE[AI_SLOT_COUNT] = {{
{fmt_arr(profile['ambient_temp_c'].values)}
}};
static const float AI_HUMIDITY_PROFILE[AI_SLOT_COUNT] = {{
{fmt_arr(profile['ambient_humidity_pct'].values)}
}};

static const float AI_POWER_MEAN[AI_POWER_FEATURES] = {{
{fmt_arr(power_model['mean'])}
}};
static const float AI_POWER_SCALE[AI_POWER_FEATURES] = {{
{fmt_arr(power_model['scale'])}
}};
static const float AI_POWER_COEF[AI_POWER_FEATURES] = {{
{fmt_arr(power_model['coef'])}
}};
static const float AI_POWER_INTERCEPT = {cfloat(power_model['intercept'])};

static const float AI_NEXT_MEAN[AI_NEXT_FEATURES] = {{
{fmt_arr(next_model['mean'])}
}};
static const float AI_NEXT_SCALE[AI_NEXT_FEATURES] = {{
{fmt_arr(next_model['scale'])}
}};
static const float AI_NEXT_COEF[AI_NEXT_FEATURES] = {{
{fmt_arr(next_model['coef'])}
}};
static const float AI_NEXT_INTERCEPT = {cfloat(next_model['intercept'])};
"""

    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "SolarAI_Model.generated.h").write_text(header, encoding="utf-8")
    (outdir / "ai_model_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    df.to_csv(outdir / "auto_training_dataset.csv", index=False)
    return metrics


def replace_array(text: str, name: str, values_text: str) -> str:
    pattern = rf"static const float {name}\[[^\]]+\] = \{{\n.*?\n\}};"
    repl = f"static const float {name}[" + ("AI_SLOT_COUNT" if "PROFILE" in name else ("AI_POWER_FEATURES" if "POWER" in name else "AI_NEXT_FEATURES")) + "] = {\n" + values_text + "\n};"
    new_text, count = re.subn(pattern, repl, text, flags=re.S)
    if count != 1:
        raise RuntimeError(f"Could not patch {name}; found {count} matches.")
    return new_text


def patch_sketch(sketch: Path, generated_header: Path) -> None:
    text = sketch.read_text(encoding="utf-8")
    header = generated_header.read_text(encoding="utf-8")

    m = re.search(r'static const char\* AI_MODEL_NAME = "([^"]+)";', header)
    if m:
        text = re.sub(r'static const char\* AI_MODEL_NAME = "[^"]+";', f'static const char* AI_MODEL_NAME = "{m.group(1)}";', text, count=1)

    for name in [
        "AI_IRR_PROFILE", "AI_AMBIENT_PROFILE", "AI_HUMIDITY_PROFILE",
        "AI_POWER_MEAN", "AI_POWER_SCALE", "AI_POWER_COEF",
        "AI_NEXT_MEAN", "AI_NEXT_SCALE", "AI_NEXT_COEF",
    ]:
        arr_m = re.search(rf"static const float {name}\[[^\]]+\] = \{{\n(.*?)\n\}};", header, flags=re.S)
        if not arr_m:
            raise RuntimeError(f"Generated header missing {name}")
        text = replace_array(text, name, arr_m.group(1))

    for name in ["AI_POWER_INTERCEPT", "AI_NEXT_INTERCEPT"]:
        val_m = re.search(rf"static const float {name} = ([^;]+);", header)
        if not val_m:
            raise RuntimeError(f"Generated header missing {name}")
        text = re.sub(rf"static const float {name} = [^;]+;", f"static const float {name} = {val_m.group(1)};", text, count=1)

    backup = sketch.with_suffix(sketch.suffix + ".bak")
    backup.write_text(sketch.read_text(encoding="utf-8"), encoding="utf-8")
    sketch.write_text(text, encoding="utf-8")
    print(f"Patched sketch: {sketch}")
    print(f"Backup saved: {backup}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--esp32", help="SensorHub base URL, e.g. http://192.168.1.50")
    ap.add_argument("--base-excel", default="training_data.xlsx", help="Original Excel training file. Use empty value to skip.")
    ap.add_argument("--extra-csv", action="append", default=[], help="Extra CSV logs to include. Can be repeated.")
    ap.add_argument("--outdir", default="ai_auto_output", help="Output folder")
    ap.add_argument("--patch-sketch", help="Optional SensorHub .ino path to update with the generated model arrays")
    args = ap.parse_args()

    outdir = Path(args.outdir)
    frames = []

    base_excel = Path(args.base_excel) if args.base_excel else None
    base_df = read_excel_or_none(base_excel)
    if not base_df.empty:
        frames.append(base_df)
        print(f"Loaded base Excel rows: {len(base_df)}")

    if args.esp32:
        live_df = download_esp32_csv(args.esp32)
        raw_path = outdir / "downloaded_esp32_log.csv"
        outdir.mkdir(parents=True, exist_ok=True)
        live_df.to_csv(raw_path, index=False)
        frames.append(live_df)
        print(f"Downloaded ESP32 rows: {len(live_df)} -> {raw_path}")

    for csv_path_s in args.extra_csv:
        csv_path = Path(csv_path_s)
        csv_df = read_csv_or_none(csv_path)
        if not csv_df.empty:
            frames.append(csv_df)
            print(f"Loaded extra CSV rows: {len(csv_df)} from {csv_path}")

    if not frames:
        print("No data loaded. Provide --esp32, --base-excel, or --extra-csv.", file=sys.stderr)
        return 2

    df = clean_training_frame(pd.concat(frames, ignore_index=True, sort=False))
    print(f"Valid training rows after cleaning: {len(df)}")
    metrics = train_model(df, outdir)
    print(json.dumps(metrics, indent=2))
    print(f"Generated: {outdir / 'SolarAI_Model.generated.h'}")
    print(f"Generated: {outdir / 'ai_model_metrics.json'}")

    if args.patch_sketch:
        patch_sketch(Path(args.patch_sketch), outdir / "SolarAI_Model.generated.h")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
