#!/usr/bin/env python3
"""Local retraining server for the SolarTrack AI dashboard.

Run on the same laptop/browser that opens the ESP32 dashboard:
  python retraining_server.py --base-excel training_data.xlsx --outdir ai_auto_output

Dashboard default server URL: http://127.0.0.1:5055
The ESP32 validates whether enough CSV data exists; this server downloads /download,
merges it with the original Excel data, retrains the Ridge/profile model, and writes:
  ai_auto_output/SolarAI_Model.generated.h
  ai_auto_output/ai_model_metrics.json
  ai_auto_output/auto_training_dataset.csv
"""
from __future__ import annotations

import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pandas as pd

from auto_retrain_from_esp32 import (
    read_excel_or_none,
    download_esp32_csv,
    clean_training_frame,
    train_model,
)

MIN_LIVE_ROWS = 288
MIN_LIVE_DATES = 3

class TrainerHandler(BaseHTTPRequestHandler):
    base_excel: Path | None = None
    outdir: Path = Path('ai_auto_output')

    def _send(self, code: int, payload: dict):
        body = json.dumps(payload, indent=2).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._send(200, {'ok': True})

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/status':
            return self._send(200, {'ok': True, 'service': 'SolarTrack AI retraining server'})
        if parsed.path != '/retrain':
            return self._send(404, {'ok': False, 'error': 'Use /retrain?esp=http://ESP32_IP'})
        qs = parse_qs(parsed.query)
        esp = (qs.get('esp') or [''])[0].strip().rstrip('/')
        if not esp.startswith('http'):
            return self._send(400, {'ok': False, 'error': 'Missing esp URL. Example: /retrain?esp=http://192.168.1.50'})
        try:
            self.outdir.mkdir(parents=True, exist_ok=True)
            live_raw = download_esp32_csv(esp)
            (self.outdir / 'downloaded_esp32_log.csv').write_text(live_raw.to_csv(index=False), encoding='utf-8')
            live_clean = clean_training_frame(live_raw)
            live_dates = int(live_clean['date_yyyy_mm_dd'].nunique()) if not live_clean.empty else 0
            if len(live_clean) < MIN_LIVE_ROWS or live_dates < MIN_LIVE_DATES:
                return self._send(409, {
                    'ok': False,
                    'error': 'Not enough ESP32 CSV data for retraining yet.',
                    'live_valid_rows': int(len(live_clean)),
                    'live_dates': live_dates,
                    'required_rows': MIN_LIVE_ROWS,
                    'required_dates': MIN_LIVE_DATES,
                })
            frames = []
            base = read_excel_or_none(self.base_excel) if self.base_excel else pd.DataFrame()
            if not base.empty:
                frames.append(base)
            frames.append(live_raw)
            df = clean_training_frame(pd.concat(frames, ignore_index=True, sort=False))
            metrics = train_model(df, self.outdir)
            return self._send(200, {'ok': True, **metrics})
        except Exception as exc:
            return self._send(500, {'ok': False, 'error': str(exc)})


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='127.0.0.1')
    ap.add_argument('--port', type=int, default=5055)
    ap.add_argument('--base-excel', default='training_data.xlsx')
    ap.add_argument('--outdir', default='ai_auto_output')
    args = ap.parse_args()
    TrainerHandler.base_excel = Path(args.base_excel) if args.base_excel else None
    TrainerHandler.outdir = Path(args.outdir)
    httpd = ThreadingHTTPServer((args.host, args.port), TrainerHandler)
    print(f'SolarTrack AI retraining server running at http://{args.host}:{args.port}')
    print('Open the ESP32 dashboard and press Run Retraining when the CSV is ready.')
    httpd.serve_forever()
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
