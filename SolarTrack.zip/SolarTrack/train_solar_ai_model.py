#!/usr/bin/env python3
"""
Train the embedded Solar Tracker AI model from the Excel dataset.

Usage:
  python train_solar_ai_model.py training_data.xlsx

Output:
  - SolarAI_Model.generated.h
  - ai_model_metrics.json

Notes:
  The generated header contains arrays for the same Ridge regression + 96-slot
  daily profile strategy embedded in SensorHub_AI_Forecast_Professional_Dashboard.ino.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


def make_power_features(data: pd.DataFrame) -> pd.DataFrame:
    h = data["hour_decimal"].astype(float).values
    irr = data["irradiance_est_w_m2"].astype(float).values
    return pd.DataFrame({
        "h_sin": np.sin(2 * np.pi * h / 24),
        "h_cos": np.cos(2 * np.pi * h / 24),
        "h2_sin": np.sin(4 * np.pi * h / 24),
        "h2_cos": np.cos(4 * np.pi * h / 24),
        "irradiance": irr,
        "irradiance2": (irr / 1000.0) ** 2,
        "ambient": data["ambient_temp_c"].astype(float).values,
        "humidity": data["ambient_humidity_pct"].astype(float).values,
        "panel": data["panel_temp_est_c"].astype(float).values,
        "dust": data["dust_est_ug_m3"].astype(float).values,
        "rain_pct": data["rain_wet_pct"].astype(float).values,
        "rain_wet": data["rain_digital_wet"].astype(float).values,
        "light_pct": data["light_avg_pct"].astype(float).values,
    })


def cfloat(v: float, digits: int = 8) -> str:
    s = f"{float(v):.{digits}g}"
    if "nan" in s.lower() or "inf" in s.lower():
        s = "0.0"
    if "." not in s and "e" not in s and "E" not in s:
        s += ".0"
    return s + "f"


def fmt_arr(vals, per_line: int = 8, digits: int = 8) -> str:
    vals = list(vals)
    lines = []
    for i in range(0, len(vals), per_line):
        lines.append("  " + ", ".join(cfloat(v, digits) for v in vals[i:i + per_line]))
    return ",\n".join(lines)


def model_dict(pipe, names):
    scaler = pipe.named_steps["standardscaler"]
    ridge = pipe.named_steps["ridgecv"]
    return {
        "features": names,
        "mean": scaler.mean_.astype(float).tolist(),
        "scale": scaler.scale_.astype(float).tolist(),
        "coef": ridge.coef_.astype(float).tolist(),
        "intercept": float(ridge.intercept_),
        "alpha": float(ridge.alpha_),
    }


def main() -> int:
    xlsx_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("training_data.xlsx")
    if not xlsx_path.exists():
        print(f"Excel file not found: {xlsx_path}", file=sys.stderr)
        return 2

    df = pd.read_excel(xlsx_path, sheet_name="Readings_Month")
    df["timestamp"] = pd.to_datetime(df["timestamp_iso"])
    df["slot"] = np.clip(np.floor(df["hour_decimal"].astype(float) * 4 + 1e-6).astype(int), 0, 95)

    X = make_power_features(df)
    y = df["solar_power_w"].astype(float).values
    cut = pd.Timestamp("2026-06-08T00:00:00+03:00")
    train_mask = df["timestamp"] < cut

    alphas = np.logspace(-4, 4, 30)
    power_pipe = make_pipeline(StandardScaler(), RidgeCV(alphas=alphas, cv=5))
    power_pipe.fit(X[train_mask], y[train_mask])
    power_pred = np.clip(power_pipe.predict(X[~train_mask]), 0, 30)

    df2 = df.copy()
    power = df2["solar_power_w"].astype(float).values
    target_next = np.full(len(df2), np.nan)
    for i in range(len(df2) - 4):
        if (df2["timestamp"].iloc[i + 4] - df2["timestamp"].iloc[i]) == pd.Timedelta(hours=1):
            target_next[i] = power[i + 1:i + 5].sum() * 0.25
    df2["target_next_hour_wh"] = target_next
    mask = ~np.isnan(target_next)

    Xn = make_power_features(df2.loc[mask]).copy()
    Xn["current_power"] = df2.loc[mask, "solar_power_w"].astype(float).values
    Xn["bus_v"] = df2.loc[mask, "solar_bus_v"].astype(float).values
    Xn["current_a"] = df2.loc[mask, "solar_current_a"].astype(float).values
    yn = df2.loc[mask, "target_next_hour_wh"].astype(float).values
    train_mask_n = df2.loc[mask, "timestamp"] < cut

    next_pipe = make_pipeline(StandardScaler(), RidgeCV(alphas=alphas, cv=5))
    next_pipe.fit(Xn[train_mask_n], yn[train_mask_n])
    next_pred = np.clip(next_pipe.predict(Xn[~train_mask_n]), 0, 30)

    profile = df.groupby("slot").agg({
        "irradiance_est_w_m2": "mean",
        "ambient_temp_c": "mean",
        "ambient_humidity_pct": "mean",
    }).reindex(range(96)).interpolate().ffill().bfill()

    power_model = model_dict(power_pipe, list(X.columns))
    next_model = model_dict(next_pipe, list(Xn.columns))

    metrics = {
        "dataset_rows": int(len(df)),
        "dataset_date_min": str(df["date_yyyy_mm_dd"].min()),
        "dataset_date_max": str(df["date_yyyy_mm_dd"].max()),
        "instant_power": {
            "mae_w": float(mean_absolute_error(y[~train_mask], power_pred)),
            "rmse_w": float(mean_squared_error(y[~train_mask], power_pred) ** 0.5),
            "r2": float(r2_score(y[~train_mask], power_pred)),
            "alpha": power_model["alpha"],
        },
        "next_hour_energy": {
            "mae_wh": float(mean_absolute_error(yn[~train_mask_n], next_pred)),
            "rmse_wh": float(mean_squared_error(yn[~train_mask_n], next_pred) ** 0.5),
            "r2": float(r2_score(yn[~train_mask_n], next_pred)),
            "alpha": next_model["alpha"],
        },
        "features": {
            "instant_power": power_model["features"],
            "next_hour": next_model["features"],
        },
    }

    header = f"""// Auto-generated by train_solar_ai_model.py
// Copy these arrays into the Embedded AI forecast model block in the SensorHub sketch.
static const float AI_IRR_PROFILE[96] = {{
{fmt_arr(profile["irradiance_est_w_m2"].values)}
}};
static const float AI_AMBIENT_PROFILE[96] = {{
{fmt_arr(profile["ambient_temp_c"].values)}
}};
static const float AI_HUMIDITY_PROFILE[96] = {{
{fmt_arr(profile["ambient_humidity_pct"].values)}
}};

static const float AI_POWER_MEAN[] = {{
{fmt_arr(power_model["mean"])}
}};
static const float AI_POWER_SCALE[] = {{
{fmt_arr(power_model["scale"])}
}};
static const float AI_POWER_COEF[] = {{
{fmt_arr(power_model["coef"])}
}};
static const float AI_POWER_INTERCEPT = {cfloat(power_model["intercept"])};

static const float AI_NEXT_MEAN[] = {{
{fmt_arr(next_model["mean"])}
}};
static const float AI_NEXT_SCALE[] = {{
{fmt_arr(next_model["scale"])}
}};
static const float AI_NEXT_COEF[] = {{
{fmt_arr(next_model["coef"])}
}};
static const float AI_NEXT_INTERCEPT = {cfloat(next_model["intercept"])};
"""

    Path("SolarAI_Model.generated.h").write_text(header, encoding="utf-8")
    Path("ai_model_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    print("Generated: SolarAI_Model.generated.h")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
