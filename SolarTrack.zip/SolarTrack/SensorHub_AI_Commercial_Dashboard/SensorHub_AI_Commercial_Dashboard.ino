/*
  Dual ESP32 Solar Tracker - SENSOR HUB
  COMMERCIAL AI FORECAST DASHBOARD - SENSOR HUB

  CRITICAL NOTE:
  This version removes the DS18B20 completely.

  Current sensor behavior:
    - INA226 on I2C GPIO21/GPIO22 only.
    - DHT22 DATA on GPIO4, using the old DS18B20 socket/wire position.
    - One stable temperature value and one humidity value from DHT22.
    - LDR TL/TR/BL/BR on GPIO32/33/34/35.
    - UART2 RX/TX on GPIO16/GPIO17.

  Added around the working test code only:
    - English professional dashboard.
    - Every sensor displayed in a separate card.
    - Offline live canvas charts.
    - CSV logging every 15 minutes to LittleFS.
    - WiFi STA preconfigured for Mekkawy and backup AP SolarTracker_AP.
    - Dashboard buttons to test actuator ESP32.
    - Embedded AI forecast model trained from the Excel dataset.
    - Next-hour and tomorrow production forecasts displayed in the dashboard and CSV.
*/

// Forward declaration for Arduino auto-prototype generation (ESP32 Arduino core 3.x).
// Function signatures below deliberately use `struct TimeFields` to avoid Arduino IDE prototype errors.
struct TimeFields;
struct DayEnergySummary;
struct AiForecastSummary;
struct RetrainDatasetStatus;

#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <WebServer.h>
#include <Preferences.h>
#include <LittleFS.h>
#include <DHT.h>
#include <limits.h>
#include <math.h>
#include <time.h>

// ---------------- WiFi / Dashboard ----------------
static const char* AP_SSID = "SolarTracker_AP";
static const char* AP_PASS = "12345678";

// Preconfigured router WiFi. The AP remains active as a backup dashboard.
static const char* DEFAULT_STA_SSID = "elnahas";
static const char* DEFAULT_STA_PASS = "kb323911";


// ---------------- Optional tomorrow weather forecast ----------------
// Default coordinates are Cairo, Egypt. Change these to your site for better forecasts.
static const bool WEATHER_FORECAST_ENABLED = true;
static const float SITE_LATITUDE = 30.0444f;
static const float SITE_LONGITUDE = 31.2357f;
static const uint32_t WEATHER_UPDATE_PERIOD_MS = 6UL * 60UL * 60UL * 1000UL;
static const uint8_t WEATHER_HOURLY_MAX = 48;

static bool weatherOK = false;
static uint32_t weatherLastFetchMs = 0;
static int weatherLastHttpCode = 0;
static String weatherStatus = "Not fetched yet";
static float weatherShortwave[WEATHER_HOURLY_MAX];
static float weatherTemp[WEATHER_HOURLY_MAX];
static float weatherHumidity[WEATHER_HOURLY_MAX];
static float weatherCloud[WEATHER_HOURLY_MAX];
static float weatherRainProb[WEATHER_HOURLY_MAX];
static uint8_t weatherCount = 0;

static const char* LOG_PATH = "/log.csv";
static const uint32_t LOG_PERIOD_MS = 15UL * 60UL * 1000UL;
static const size_t LOG_MAX_BYTES = 2UL * 1024UL * 1024UL;

// ---------------- Pin map: ESP32 #1 Sensor Hub ----------------
static const uint8_t PIN_PD_TL     = 32;  // BPW34 Top-Left, ADC1_CH4
static const uint8_t PIN_PD_TR     = 33;  // BPW34 Top-Right, ADC1_CH5
static const uint8_t PIN_PD_BL     = 34;  // BPW34 Bottom-Left, ADC1_CH6, input-only
static const uint8_t PIN_PD_BR     = 35;  // BPW34 Bottom-Right, ADC1_CH7, input-only
static const uint8_t PIN_RAIN_AO   = 39;  // HW-028 AO, ADC1_CH3, input-only
static const uint8_t PIN_RAIN_DO   = 27;  // HW-028 DO
static const uint8_t PIN_DUST_VO   = 36;  // GP2Y1010 Vo, ADC1_CH0, input-only
static const uint8_t PIN_DUST_LED  = 25;  // GP2Y1010 LED drive
static const uint8_t PIN_PIR_1     = 14;
static const uint8_t PIN_PIR_2     = 13;
static const uint8_t PIN_TILT      = 26;  // KY-017, internal pull-up
static const uint8_t PIN_DHT       = 4;   // DHT22 DATA on the old DS18B20 socket/GPIO4.
static const uint8_t PIN_I2C_SDA   = 21;  // INA226 I2C SDA.
static const uint8_t PIN_I2C_SCL   = 22;  // INA226 I2C SCL only. Do not connect DHT here.
static const uint8_t PIN_UART_RX2  = 16;
static const uint8_t PIN_UART_TX2  = 17;

// ---------------- Device addresses ----------------
static const uint8_t INA226_ADDR = 0x40;

// ---------------- DHT22 ----------------
#define DHTTYPE DHT22
static const uint32_t DHT_READ_PERIOD_MS = 2500;   // DHT22 should not be read faster than about every 2 seconds.
static const uint32_t I2C_FREQ_HZ = 100000;
static const uint32_t DHT_STALE_AFTER_MS = 300000; // keep last good DHT value for short read misses.
static const float DHT_FILTER_ALPHA = 0.20f;       // Low-pass filter: smaller = steadier display.

// ---------------- ADC / filtering ----------------
static const uint8_t LIGHT_ADC_SAMPLES = 8;
static const uint8_t RAIN_ADC_SAMPLES  = 8;
static const uint8_t DUST_ADC_SAMPLES  = 3;

// ---------------- Rain module tuning ----------------
// Many LM393 rain boards use DO LOW = wet. If your board is reversed, set this to false.
static const bool RAIN_DO_LOW_IS_WET = true;

// Analog wet percentage is only for Serial display. Adjust after measuring dry/wet values.
static const bool RAIN_AO_LOW_IS_WET = true;
static const uint16_t RAIN_AO_DRY_RAW = 4095;
static const uint16_t RAIN_AO_WET_RAW = 1200;

// ---------------- GP2Y1010 dust timing / display tuning ----------------
// Most GP2Y1010 modules/transistor circuits are active LOW: LOW = LED ON, HIGH = LED OFF.
// If your LED drive is active HIGH, change this to false.
static const bool DUST_LED_ACTIVE_LOW = true;
// Display-only rough conversion. Calibrate with clean-air reading for better results.
static const float ADC_REF_V = 3.30f;
static const float DUST_ZERO_VOLTAGE = 0.90f;          // V in clean air, typical placeholder
static const float DUST_V_PER_UG_M3 = 0.005f;          // V per ug/m3, approximate placeholder

// ---------------- AI dataset / derived engineering values ----------------
static const uint8_t CSV_SCHEMA_VERSION = 5;
// Egypt local time. This POSIX TZ string handles the usual Egypt summer-time rule used by ESP-IDF/newlib.
// If your board shows one hour off, replace with fixed UTC+2: "EET-2".
static const char* TZ_INFO = "EET-2EEST,M4.5.5/0,M10.5.4/24";

// Irradiance is estimated from the four light ADC channels until a real pyranometer calibration is added.
// Calibrate this value by comparing light_avg_raw against a reference irradiance meter at noon.
static const float IRRADIANCE_FULL_SCALE_WM2 = 1000.0f; // raw 4095 ~= 1000 W/m^2 after calibration assumption.
static const uint8_t IRRADIANCE_SOURCE_ESTIMATED_LDR = 1;

// Panel/cell temperature estimate from ambient temperature and irradiance using the NOCT approximation:
// T_panel = T_ambient + ((NOCT - 20) / 800) * Irradiance_Wm2
static const float PANEL_NOCT_C = 45.0f;
static const uint8_t PANEL_TEMP_SOURCE_CALCULATED_FROM_AMBIENT = 2;

// ---------------- UART framed protocol ----------------
static const uint8_t FRAME_START = 0xAA;
static const uint8_t MSG_HELLO   = 0x01;
static const uint8_t MSG_SENSOR  = 0x10;
static const uint8_t MSG_ACK     = 0x11;
static const uint8_t MSG_STATUS  = 0x20;
static const uint8_t MSG_CMD     = 0x30;
static const uint8_t MAX_PAYLOAD = 160;

static const uint16_t SFLAG_DHT_OK       = 1 << 0;
static const uint16_t SFLAG_INA_OK       = 1 << 1;
static const uint16_t SFLAG_TEMP_OK      = 1 << 2;  // Legacy temperature bit kept for UART payload compatibility.
static const uint16_t SFLAG_ADC_EXTREME  = 1 << 3;
static const uint16_t SFLAG_RAIN_WET     = 1 << 4;
static const uint16_t SFLAG_PIR1_ACTIVE  = 1 << 5;
static const uint16_t SFLAG_PIR2_ACTIVE  = 1 << 6;
static const uint16_t SFLAG_TILT_ACTIVE  = 1 << 7;

enum CommandId : uint8_t {
  CMD_NONE = 0,
  CMD_ARM = 1,
  CMD_DISARM = 2,
  CMD_AUTO = 3,
  CMD_MANUAL = 4,
  CMD_STOP = 5,
  CMD_MOTOR = 6,
  CMD_SERVO = 7,
  CMD_CENTER = 8,
  CMD_PUMP = 9,
  CMD_CLEAN = 10,
  CMD_ALL_OFF = 11,
  CMD_CLEAN_AUTO = 12
};

#pragma pack(push, 1)
struct SensorPayload {
  uint16_t seq;
  uint32_t uptime_ms;
  uint16_t adcTL;
  uint16_t adcTR;
  uint16_t adcBL;
  uint16_t adcBR;
  int16_t lightErrH;
  int16_t lightErrV;
  uint16_t rainAO;
  uint16_t dustRaw;
  uint8_t rainDO;
  uint8_t pir1;
  uint8_t pir2;
  uint8_t tilt;
  int16_t legacyTempC_x100; // Same payload position as the old panel-temperature field; now mirrors DHT22 temperature.
  int16_t dhtTempC_x100;
  uint32_t dhtHumidity_x100;
  uint16_t bus_mV;
  int32_t shunt_uV;
  int32_t current_mA;
  uint32_t power_mW;
  uint16_t sensorFlags;
};

struct AckPayload {
  uint16_t seq;
  uint8_t ok;
  uint32_t rxFrames;
  uint32_t lostFrames;
  uint32_t crcFails;
  int16_t motorDuty;
  uint8_t testStage;
};

struct ActuatorStatusPayload {
  uint16_t lastSeq;
  uint32_t uptime_ms;
  uint32_t rxFrames;
  uint32_t lostFrames;
  uint32_t crcFails;
  uint32_t cmdFrames;
  uint8_t linkOK;
  uint8_t armed;
  uint8_t autoMode;
  uint8_t limitActive;
  uint8_t cleaningActive;
  uint8_t pumpOn;
  uint8_t autoCleaning;
  uint8_t testStage;
  int16_t servoDeg;
  int16_t motorDuty;
  int16_t errH_norm;
  int16_t errV_norm;
  uint16_t lightTotal;
  int32_t lastCurrent_mA;
  uint16_t lastSensorFlags;
  uint8_t faultCode;
  uint32_t lastCleanAgo_s;
};

struct CommandPayload {
  uint32_t nonce;
  uint8_t cmd;
  int16_t value;
  uint16_t ms;
};
#pragma pack(pop)

HardwareSerial LinkSerial(2);
WebServer server(80);
Preferences prefs;
DHT dht(PIN_DHT, DHTTYPE);

bool inaOK = false;
bool streamEnabled = true;
uint16_t nextSeq = 1;
uint32_t lastSampleMs = 0;
uint32_t lastPrintMs = 0;
uint32_t samplePeriodMs = 500;
uint32_t lastLogMs = 0;
bool latestValid = false;
SensorPayload latest{};
ActuatorStatusPayload latestAct{};
bool haveActStatus = false;

uint32_t txSensorFrames = 0;
uint32_t txCmdFrames = 0;
uint32_t rxAckFrames = 0;
uint32_t rxStatusFrames = 0;
uint32_t rxCrcFails = 0;
uint32_t rxBadFrames = 0;
uint32_t lastAckMs = 0;
uint16_t lastAckSeq = 0;

uint32_t lastDhtReadMs = 0;
uint32_t lastDhtGoodMs = 0;
uint8_t dhtFailStreak = 0;
bool cachedDhtOK = false;
int16_t cachedDhtTempC_x100 = INT16_MIN;
uint32_t cachedDhtHumidity_x100 = 0;

float filteredDhtTempC = NAN;
float filteredDhtHumidity = NAN;

uint32_t commandNonce = 1;
bool staOK = false;
String staIP = "";

// ---------------- CRC-8 MAXIM ----------------
uint8_t crc8MaximUpdate(uint8_t crc, uint8_t data) {
  crc ^= data;
  for (uint8_t i = 0; i < 8; i++) crc = (crc & 0x01) ? (crc >> 1) ^ 0x8C : (crc >> 1);
  return crc;
}

uint8_t crc8Maxim(const uint8_t *data, uint8_t len) {
  uint8_t crc = 0;
  for (uint8_t i = 0; i < len; i++) crc = crc8MaximUpdate(crc, data[i]);
  return crc;
}

void sendFrame(Stream &s, uint8_t msgId, const uint8_t *payload, uint8_t payloadLen) {
  uint8_t len = payloadLen + 1;
  uint8_t crc = 0;
  s.write(FRAME_START);
  s.write(len);
  crc = crc8MaximUpdate(crc, len);
  s.write(msgId);
  crc = crc8MaximUpdate(crc, msgId);
  for (uint8_t i = 0; i < payloadLen; i++) {
    s.write(payload[i]);
    crc = crc8MaximUpdate(crc, payload[i]);
  }
  s.write(crc);
}

bool readFrame(Stream &s, uint8_t &msgId, uint8_t *payload, uint8_t &payloadLen) {
  static enum { WAIT_START, READ_LEN, READ_BODY, READ_CRC } state = WAIT_START;
  static uint8_t len = 0;
  static uint8_t body[MAX_PAYLOAD + 1];
  static uint8_t idx = 0;
  static uint8_t crc = 0;

  while (s.available()) {
    uint8_t b = (uint8_t)s.read();
    switch (state) {
      case WAIT_START:
        if (b == FRAME_START) state = READ_LEN;
        break;
      case READ_LEN:
        len = b;
        if (len < 1 || len > MAX_PAYLOAD + 1) {
          rxBadFrames++;
          state = WAIT_START;
        } else {
          idx = 0;
          crc = crc8MaximUpdate(0, len);
          state = READ_BODY;
        }
        break;
      case READ_BODY:
        body[idx++] = b;
        crc = crc8MaximUpdate(crc, b);
        if (idx >= len) state = READ_CRC;
        break;
      case READ_CRC:
        if (b == crc) {
          msgId = body[0];
          payloadLen = len - 1;
          if (payloadLen) memcpy(payload, &body[1], payloadLen);
          state = WAIT_START;
          return true;
        } else {
          rxCrcFails++;
          state = WAIT_START;
        }
        break;
    }
  }
  return false;
}

// ---------------- I2C helpers / INA226 - from working test ----------------
bool i2cPresent(uint8_t addr) {
  Wire.beginTransmission(addr);
  return Wire.endTransmission() == 0;
}

void i2cScan() {
  Serial.println(F("\nI2C scan on GPIO21/GPIO22:"));
  uint8_t found = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.print(F("  Found 0x"));
      if (addr < 16) Serial.print('0');
      Serial.println(addr, HEX);
      found++;
      delay(2);
    }
  }
  if (!found) Serial.println(F("  No I2C devices found."));
}

void writeReg16(uint8_t addr, uint8_t reg, uint16_t value) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write((uint8_t)(value >> 8));
  Wire.write((uint8_t)(value & 0xFF));
  Wire.endTransmission();
}

uint16_t readReg16(uint8_t addr, uint8_t reg) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return 0;
  Wire.requestFrom((int)addr, 2);
  if (Wire.available() < 2) return 0;
  return ((uint16_t)Wire.read() << 8) | Wire.read();
}

void calibrateINA226() {
  writeReg16(INA226_ADDR, 0x05, 2560);
  writeReg16(INA226_ADDR, 0x00, 0x4527);
}

// ---------------- Utility / sensor reads - from working test ----------------
uint16_t readAnalogAvg(uint8_t pin, uint8_t samples, uint16_t pauseUs = 250) {
  uint32_t sum = 0;
  for (uint8_t i = 0; i < samples; i++) {
    sum += analogRead(pin);
    if (pauseUs) delayMicroseconds(pauseUs);
  }
  return (uint16_t)((sum + samples / 2) / samples);
}

uint16_t readDustRawOnce() {
  const uint8_t ledOn = DUST_LED_ACTIVE_LOW ? LOW : HIGH;
  const uint8_t ledOff = DUST_LED_ACTIVE_LOW ? HIGH : LOW;
  digitalWrite(PIN_DUST_LED, ledOn);
  delayMicroseconds(280);
  uint16_t raw = analogRead(PIN_DUST_VO);
  delayMicroseconds(40);
  digitalWrite(PIN_DUST_LED, ledOff);
  delayMicroseconds(9680);
  return raw;
}

uint16_t readDustRawAvg(uint8_t samples) {
  uint32_t sum = 0;
  for (uint8_t i = 0; i < samples; i++) sum += readDustRawOnce();
  return (uint16_t)((sum + samples / 2) / samples);
}

int16_t x100OrError(float v, float minOk, float maxOk) {
  if (isnan(v) || v < minOk || v > maxOk) return INT16_MIN;
  float scaled = v * 100.0f;
  if (scaled < -32767.0f || scaled > 32767.0f) return INT16_MIN;
  return (int16_t)roundf(scaled);
}

void restartI2CBus() {
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, I2C_FREQ_HZ);
  delay(5);
}

void updateDHTCache(bool force = false) {
  uint32_t now = millis();
  if (!force && lastDhtReadMs != 0 && now - lastDhtReadMs < DHT_READ_PERIOD_MS) return;
  lastDhtReadMs = now;

  // DHT22 is now on GPIO4 only. GPIO22 stays dedicated to INA226 SCL.
  // This removes the old shared-line timing problem and makes readings more stable.
  float h = dht.readHumidity(true);   // force one fresh DHT transaction
  float t = dht.readTemperature();    // use the same cached DHT transaction

  int16_t rawTx100 = x100OrError(t, -40.0f, 80.0f);
  bool ok = (rawTx100 != INT16_MIN && !isnan(h) && h >= 0.0f && h <= 100.0f);

  if (ok) {
    if (isnan(filteredDhtTempC) || isnan(filteredDhtHumidity)) {
      filteredDhtTempC = t;
      filteredDhtHumidity = h;
    } else {
      filteredDhtTempC = (filteredDhtTempC * (1.0f - DHT_FILTER_ALPHA)) + (t * DHT_FILTER_ALPHA);
      filteredDhtHumidity = (filteredDhtHumidity * (1.0f - DHT_FILTER_ALPHA)) + (h * DHT_FILTER_ALPHA);
    }

    cachedDhtTempC_x100 = x100OrError(filteredDhtTempC, -40.0f, 80.0f);
    cachedDhtHumidity_x100 = (uint32_t)roundf(filteredDhtHumidity * 100.0f);
    cachedDhtOK = true;
    lastDhtGoodMs = now;
    dhtFailStreak = 0;
  } else {
    dhtFailStreak++;

    // Do not erase the last good value on one failed read.
    if (lastDhtGoodMs != 0 && now - lastDhtGoodMs < DHT_STALE_AFTER_MS) {
      cachedDhtOK = true;
    } else {
      cachedDhtTempC_x100 = INT16_MIN;
      cachedDhtHumidity_x100 = 0;
      filteredDhtTempC = NAN;
      filteredDhtHumidity = NAN;
      cachedDhtOK = false;
    }
  }
}

float rawToVolts(uint16_t raw) {
  return ((float)raw * ADC_REF_V) / 4095.0f;
}

float milliVoltsToVolts(uint16_t mv) {
  return (float)mv / 1000.0f;
}

float microVoltsToVolts(int32_t uv) {
  return (float)uv / 1000000.0f;
}

float milliAmpsToAmps(int32_t ma) {
  return (float)ma / 1000.0f;
}

float milliWattsToWatts(uint32_t mw) {
  return (float)mw / 1000.0f;
}

float dustRawToUgM3(uint16_t raw) {
  float v = rawToVolts(raw);
  float ugm3 = (v - DUST_ZERO_VOLTAGE) / DUST_V_PER_UG_M3;
  if (ugm3 < 0.0f) ugm3 = 0.0f;
  return ugm3;
}

uint8_t rainWetPercent(uint16_t raw) {
  int32_t dry = RAIN_AO_DRY_RAW;
  int32_t wet = RAIN_AO_WET_RAW;
  if (dry == wet) return 0;

  int32_t percent;
  if (RAIN_AO_LOW_IS_WET) {
    percent = ((dry - (int32_t)raw) * 100L) / (dry - wet);
  } else {
    percent = (((int32_t)raw - dry) * 100L) / (wet - dry);
  }
  percent = constrain(percent, 0L, 100L);
  return (uint8_t)percent;
}

SensorPayload readAllSensors() {
  SensorPayload p{};
  p.seq = nextSeq++;
  p.uptime_ms = millis();

  p.adcTL = readAnalogAvg(PIN_PD_TL, LIGHT_ADC_SAMPLES);
  p.adcTR = readAnalogAvg(PIN_PD_TR, LIGHT_ADC_SAMPLES);
  p.adcBL = readAnalogAvg(PIN_PD_BL, LIGHT_ADC_SAMPLES);
  p.adcBR = readAnalogAvg(PIN_PD_BR, LIGHT_ADC_SAMPLES);
  p.lightErrH = (int32_t)p.adcTR + p.adcBR - (int32_t)p.adcTL - p.adcBL;
  p.lightErrV = (int32_t)p.adcTL + p.adcTR - (int32_t)p.adcBL - p.adcBR;

  p.rainAO = readAnalogAvg(PIN_RAIN_AO, RAIN_ADC_SAMPLES);
  p.rainDO = digitalRead(PIN_RAIN_DO);
  p.dustRaw = readDustRawAvg(DUST_ADC_SAMPLES);
  p.pir1 = digitalRead(PIN_PIR_1);
  p.pir2 = digitalRead(PIN_PIR_2);
  p.tilt = digitalRead(PIN_TILT);

  updateDHTCache(false);
  p.dhtTempC_x100 = cachedDhtTempC_x100;
  p.dhtHumidity_x100 = cachedDhtHumidity_x100;

  // Keep the old payload slot filled with the same DHT22 temperature so the other ESP32 protocol does not break.
  p.legacyTempC_x100 = cachedDhtTempC_x100;

  uint16_t flags = 0;
  const bool adcExtreme =
    p.adcTL <= 2 || p.adcTR <= 2 || p.adcBL <= 2 || p.adcBR <= 2 ||
    p.adcTL >= 4093 || p.adcTR >= 4093 || p.adcBL >= 4093 || p.adcBR >= 4093 ||
    p.rainAO <= 2 || p.rainAO >= 4093 || p.dustRaw <= 2 || p.dustRaw >= 4093;

  if (adcExtreme) flags |= SFLAG_ADC_EXTREME;
  if ((RAIN_DO_LOW_IS_WET && p.rainDO == LOW) || (!RAIN_DO_LOW_IS_WET && p.rainDO == HIGH)) flags |= SFLAG_RAIN_WET;
  if (p.pir1) flags |= SFLAG_PIR1_ACTIVE;
  if (p.pir2) flags |= SFLAG_PIR2_ACTIVE;
  if (p.tilt == LOW) flags |= SFLAG_TILT_ACTIVE;  // with pull-up: LOW = closed/active
  if (cachedDhtOK) flags |= SFLAG_DHT_OK | SFLAG_TEMP_OK;

  inaOK = i2cPresent(INA226_ADDR);
  if (inaOK) {
    // Re-write calibration occasionally; register can reset if INA226 brown-outs.
    static uint32_t lastCalMs = 0;
    if (millis() - lastCalMs > 10000) {
      calibrateINA226();
      lastCalMs = millis();
    }
    int16_t shuntRaw = (int16_t)readReg16(INA226_ADDR, 0x01);
    uint16_t busRaw = readReg16(INA226_ADDR, 0x02);
    uint16_t powerRaw = readReg16(INA226_ADDR, 0x03);
    int16_t currentRaw = (int16_t)readReg16(INA226_ADDR, 0x04);
    p.shunt_uV = (int32_t)shuntRaw * 25 / 10;  // 2.5 uV/bit
    p.bus_mV = (uint32_t)busRaw * 125 / 100;   // 1.25 mV/bit
    p.current_mA = (int32_t)currentRaw / 10;   // 100 uA/bit = 0.1 mA/bit
    p.power_mW = (uint32_t)powerRaw * 25 / 10; // 2.5 mW/bit with 100 uA LSB
    flags |= SFLAG_INA_OK;
  } else {
    p.bus_mV = 0;
    p.shunt_uV = 0;
    p.current_mA = 0;
    p.power_mW = 0;
  }

  p.sensorFlags = flags;
  return p;
}


// ---------------- Serial display ----------------// ---------------- Serial display ----------------
void printCompactPayload(const SensorPayload &p) {
  Serial.print(F("seq=")); Serial.print(p.seq);
  Serial.print(F(" LDR TL/TR/BL/BR="));
  Serial.print(p.adcTL); Serial.print('/'); Serial.print(p.adcTR); Serial.print('/');
  Serial.print(p.adcBL); Serial.print('/'); Serial.print(p.adcBR);
  Serial.print(F(" errH/V=")); Serial.print(p.lightErrH); Serial.print('/'); Serial.print(p.lightErrV);
  Serial.print(F(" rain%=")); Serial.print(rainWetPercent(p.rainAO));
  Serial.print(F(" dustRaw=")); Serial.print(p.dustRaw);
  Serial.print(F(" DHT22 Temp="));
  if (p.dhtTempC_x100 == INT16_MIN) Serial.print(F("ERR")); else Serial.print(p.dhtTempC_x100 / 100.0f, 2);
  Serial.print(F("C RH="));
  if (p.dhtHumidity_x100 == 0) Serial.print(F("ERR")); else Serial.print(p.dhtHumidity_x100 / 100.0f, 1);
  Serial.print(F("% V=")); Serial.print(milliVoltsToVolts(p.bus_mV), 3);
  Serial.print(F(" I=")); Serial.print(milliAmpsToAmps(p.current_mA), 3);
  Serial.print(F(" P=")); Serial.print(milliWattsToWatts(p.power_mW), 3);
  Serial.print(F(" flags=")); Serial.println(p.sensorFlags);
}

void printLinkStats() {
  const uint32_t now = millis();
  bool linkOK = (lastAckMs != 0 && now - lastAckMs < 2500);
  Serial.print(F("UART link=")); Serial.print(linkOK ? F("OK") : F("WAITING"));
  Serial.print(F(" TX/RX=")); Serial.print(txSensorFrames); Serial.print('/'); Serial.print(rxAckFrames + rxStatusFrames);
  Serial.print(F(" lastAckSeq=")); Serial.println(lastAckSeq);
}

// ---------------- Command / UART handlers ----------------
void sendCommand(uint8_t cmd, int16_t value = 0, uint16_t ms = 0, uint8_t repeats = 4) {
  CommandPayload c{};
  c.nonce = commandNonce++;
  c.cmd = cmd;
  c.value = value;
  c.ms = ms;
  for (uint8_t i = 0; i < repeats; i++) {
    sendFrame(LinkSerial, MSG_CMD, (const uint8_t *)&c, sizeof(c));
    txCmdFrames++;
    delay(8);
  }
}

void handleIncomingLink() {
  uint8_t msgId, len;
  uint8_t payload[MAX_PAYLOAD];
  while (readFrame(LinkSerial, msgId, payload, len)) {
    if (msgId == MSG_ACK && len == sizeof(AckPayload)) {
      AckPayload a;
      memcpy(&a, payload, sizeof(a));
      rxAckFrames++;
      lastAckMs = millis();
      lastAckSeq = a.seq;
    } else if (msgId == MSG_STATUS && len == sizeof(ActuatorStatusPayload)) {
      memcpy(&latestAct, payload, sizeof(latestAct));
      haveActStatus = true;
      rxStatusFrames++;
      lastAckMs = millis();
    } else {
      rxBadFrames++;
    }
  }
}

// ---------------- CSV logging ----------------
struct TimeFields {
  String iso;
  String date;
  String timeOfDay;
  int hour;
  float hourDecimal;
  uint32_t unixEpoch;
  bool synced;
};

static const char CSV_HEADER[] =
  "schema_version,timestamp_iso,date_yyyy_mm_dd,time_hh_mm_ss,hour_of_day,hour_decimal,unix_epoch_s,time_synced,uptime_s,sample_seq,"
  "ambient_temp_c,ambient_humidity_pct,panel_temp_est_c,panel_temp_source_code,dht22_ok,"
  "irradiance_est_w_m2,irradiance_source_code,light_avg_raw,light_avg_pct,ldr_tl_raw,ldr_tr_raw,ldr_bl_raw,ldr_br_raw,light_error_horizontal_raw,light_error_vertical_raw,"
  "rain_analog_raw,rain_wet_pct,rain_digital_wet,rain_do_raw,"
  "dust_raw,dust_voltage_v,dust_est_ug_m3,"
  "pir1_motion,pir2_motion,tilt_active,"
  "solar_bus_v,solar_current_a,solar_power_w,ina226_ok,"
  "sensor_flags,adc_extreme,"
  "actuator_link_ok,actuator_armed,actuator_auto_mode,motor_duty,servo_deg,pump_on,cleaning_active,limit_active,fault_code,"
  "ai_model_power_w,ai_next_hour_wh,ai_tomorrow_wh,ai_tomorrow_kwh,ai_confidence_pct,"
  "ai_tomorrow_best_wh,ai_tomorrow_normal_wh,ai_tomorrow_worst_wh,ai_baseline_normal_wh,ai_loss_gain_pct_vs_baseline,ai_uncertainty_pct,"
  "weather_used,weather_irr_avg_w_m2,weather_temp_avg_c,weather_cloud_avg_pct,weather_rain_max_pct";

// ---------------- Excel seed fallback / retraining gates ----------------
// Used only until the ESP32 CSV contains enough real logged production data.
static const char* EXCEL_SEED_LAST_DAY_DATE = "2026-06-12";
static const float EXCEL_SEED_LAST_DAY_WH = 81.4125f;
static const float EXCEL_SEED_LAST_DAY_KWH = 0.0814125f;
static const uint16_t EXCEL_SEED_LAST_DAY_SAMPLES = 96;
static const char* EXCEL_SEED_SOURCE = "excel_seed_training_data";

// Retraining is intentionally performed by the Python helper on a laptop/Raspberry Pi.
// The ESP32 only validates whether the CSV has enough clean, time-synced rows.
static const uint32_t RETRAIN_MIN_ROWS = 288;          // 3 days x 96 samples/day
static const uint16_t RETRAIN_MIN_DAYS = 3;
static const uint32_t RETRAIN_RECOMMENDED_ROWS = 672;  // 7 days x 96 samples/day


float clampFloat(float v, float lo, float hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

bool dhtValueOK(const SensorPayload &p) {
  return (p.sensorFlags & SFLAG_DHT_OK) && p.dhtTempC_x100 != INT16_MIN;
}

float x100ToFloatOrNan(int16_t x100) {
  if (x100 == INT16_MIN) return NAN;
  return (float)x100 / 100.0f;
}

float humidityToFloatOrNan(const SensorPayload &p) {
  if (!(p.sensorFlags & SFLAG_DHT_OK)) return NAN;
  return (float)p.dhtHumidity_x100 / 100.0f;
}

float lightAverageRaw(const SensorPayload &p) {
  return ((float)p.adcTL + (float)p.adcTR + (float)p.adcBL + (float)p.adcBR) / 4.0f;
}

float lightAveragePct(const SensorPayload &p) {
  return clampFloat((lightAverageRaw(p) / 4095.0f) * 100.0f, 0.0f, 100.0f);
}

float irradianceEstimateWm2(const SensorPayload &p) {
  return clampFloat((lightAverageRaw(p) / 4095.0f) * IRRADIANCE_FULL_SCALE_WM2, 0.0f, 1400.0f);
}

float panelTempEstimateC(const SensorPayload &p) {
  if (!dhtValueOK(p)) return NAN;
  float ambient = x100ToFloatOrNan(p.dhtTempC_x100);
  float irradiance = irradianceEstimateWm2(p);
  return ambient + (((PANEL_NOCT_C - 20.0f) / 800.0f) * irradiance);
}

uint8_t rainDigitalWet(const SensorPayload &p) {
  return ((RAIN_DO_LOW_IS_WET && p.rainDO == LOW) || (!RAIN_DO_LOW_IS_WET && p.rainDO == HIGH)) ? 1 : 0;
}

uint8_t tiltActive(const SensorPayload &p) {
  return (p.tilt == LOW) ? 1 : 0;
}

void csvPrintFloat(File &f, float v, uint8_t decimals) {
  if (isnan(v) || isinf(v)) f.print("NaN");
  else f.print(v, decimals);
}

String fmtFloatForJson(float v, uint8_t decimals = 2) {
  if (isnan(v) || isinf(v)) return String("null");
  return String((double)v, (unsigned int)decimals);
}

struct TimeFields getTimeFields() {
  struct TimeFields tf{};
  time_t t = time(nullptr);
  if (t > 1700000000) {
    struct tm tmv;
    localtime_r(&t, &tmv);
    char isoBuf[24];
    char dateBuf[12];
    char timeBuf[10];
    strftime(isoBuf, sizeof(isoBuf), "%Y-%m-%dT%H:%M:%S", &tmv);
    strftime(dateBuf, sizeof(dateBuf), "%Y-%m-%d", &tmv);
    strftime(timeBuf, sizeof(timeBuf), "%H:%M:%S", &tmv);
    tf.iso = String(isoBuf);
    tf.date = String(dateBuf);
    tf.timeOfDay = String(timeBuf);
    tf.hour = tmv.tm_hour;
    tf.hourDecimal = (float)tmv.tm_hour + ((float)tmv.tm_min / 60.0f) + ((float)tmv.tm_sec / 3600.0f);
    tf.unixEpoch = (uint32_t)t;
    tf.synced = true;
  } else {
    tf.iso = String("uptime_") + String(millis() / 1000) + "s";
    tf.date = "NA";
    tf.timeOfDay = "NA";
    tf.hour = -1;
    tf.hourDecimal = -1.0f;
    tf.unixEpoch = 0;
    tf.synced = false;
  }
  return tf;
}


// ---------------- Embedded AI forecast model ----------------
// Trained from: solar_cell_30w_2a_readings_12may_to_12jun_2026.xlsx
// Model type: Ridge regression + learned 96-slot daily profiles.
// Holdout after 2026-06-08:
//   Instant power MAE=0.466 W, R2=0.9936
//   Next-hour energy MAE=0.469 Wh, R2=0.9924
static const char* AI_MODEL_NAME = "solar_ridge_profile_v1_2026_06_12";
static const uint8_t AI_SLOT_COUNT = 96;
static const uint8_t AI_POWER_FEATURES = 13;
static const uint8_t AI_NEXT_FEATURES = 16;
static const float AI_TWO_PI = 6.28318530718f;
static const float AI_PANEL_RATED_POWER_W = 30.0f;

static const float AI_IRR_PROFILE[AI_SLOT_COUNT] = {
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 11.0f, 44.6875f, 81.09375f,
  119.5625f, 159.59375f, 200.71875f, 242.125f, 283.875f, 325.28125f, 366.3125f, 406.4375f,
  445.625f, 483.6875f, 520.46875f, 555.78125f, 589.15625f, 620.4375f, 649.28125f, 675.15625f,
  697.90625f, 717.46875f, 733.84375f, 747.0f, 757.5625f, 765.34375f, 771.03125f, 774.65625f,
  776.1875f, 775.25f, 771.8125f, 765.3125f, 755.625f, 742.3125f, 725.34375f, 704.875f,
  681.1875f, 654.4375f, 625.4375f, 594.3125f, 561.78125f, 527.96875f, 492.875f, 456.65625f,
  419.5f, 380.875f, 341.28125f, 300.9375f, 259.875f, 218.59375f, 177.5625f, 136.9375f,
  97.625f, 60.09375f, 25.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f
};

static const float AI_AMBIENT_PROFILE[AI_SLOT_COUNT] = {
  35.5825f, 35.309375f, 35.020625f, 34.716875f, 34.4025f, 34.079375f, 33.752187f, 33.422812f,
  33.089687f, 32.750625f, 32.407187f, 32.061875f, 31.718438f, 31.381563f, 31.051875f, 30.727812f,
  30.410937f, 30.095938f, 29.791563f, 29.498125f, 29.220625f, 28.960938f, 28.71375f, 28.4825f,
  28.264063f, 28.06f, 27.8775f, 27.715312f, 27.578125f, 27.461875f, 27.363437f, 27.284063f,
  27.225313f, 27.187812f, 27.1775f, 27.192187f, 27.229375f, 27.285937f, 27.361563f, 27.456563f,
  27.573438f, 27.71625f, 27.879687f, 28.065f, 28.265313f, 28.480625f, 28.709375f, 28.956563f,
  29.220312f, 29.502187f, 29.796875f, 30.099062f, 30.408438f, 30.72375f, 31.048125f, 31.381563f,
  31.721875f, 32.066563f, 32.408125f, 32.748125f, 33.084063f, 33.419063f, 33.750937f, 34.083125f,
  34.405625f, 34.718438f, 35.018125f, 35.303125f, 35.579375f, 35.844062f, 36.096562f, 36.335f,
  36.552188f, 36.749375f, 36.926563f, 37.084063f, 37.226875f, 37.35125f, 37.453437f, 37.530938f,
  37.585313f, 37.614375f, 37.623125f, 37.611875f, 37.5825f, 37.530938f, 37.454375f, 37.3525f,
  37.228437f, 37.08375f, 36.924375f, 36.747188f, 36.552188f, 36.33625f, 36.100313f, 35.847188f
};

static const float AI_HUMIDITY_PROFILE[AI_SLOT_COUNT] = {
  50.09375f, 50.3125f, 50.625f, 51.03125f, 51.40625f, 51.8125f, 52.0625f, 52.53125f,
  52.8125f, 53.21875f, 53.59375f, 54.0f, 54.46875f, 54.78125f, 55.21875f, 55.46875f,
  55.875f, 56.21875f, 56.46875f, 56.90625f, 57.28125f, 57.59375f, 57.84375f, 58.15625f,
  58.53125f, 58.6875f, 58.8125f, 59.125f, 59.15625f, 59.375f, 59.4375f, 59.65625f,
  59.6875f, 59.65625f, 59.71875f, 59.6875f, 59.5625f, 59.53125f, 59.46875f, 59.4375f,
  59.21875f, 58.96875f, 58.78125f, 58.59375f, 58.375f, 58.0625f, 57.8125f, 57.5f,
  57.21875f, 56.875f, 56.65625f, 56.25f, 55.875f, 55.59375f, 55.25f, 54.84375f,
  54.46875f, 54.03125f, 53.75f, 53.4375f, 52.96875f, 52.65625f, 52.21875f, 51.71875f,
  51.375f, 51.09375f, 50.6875f, 50.375f, 50.0625f, 49.71875f, 49.40625f, 49.0625f,
  48.78125f, 48.5625f, 48.46875f, 48.21875f, 48.03125f, 47.9375f, 47.75f, 47.625f,
  47.71875f, 47.65625f, 47.65625f, 47.6875f, 47.6875f, 47.71875f, 47.71875f, 48.03125f,
  48.09375f, 48.34375f, 48.53125f, 48.78125f, 48.875f, 49.15625f, 49.4375f, 49.8125f
};

// Features: h_sin, h_cos, h2_sin, h2_cos, irradiance, irradiance2, ambient, humidity, panel, dust, rain_pct, rain_wet, light_pct
static const float AI_POWER_MEAN[AI_POWER_FEATURES] = {
  -1.5077103e-17f, -4.7287277e-17f, 4.79726e-18f, -7.435753e-17f, 271.42593f, 0.17430206f, 32.067434f, 53.839506f,
  38.771671f, 28.403472f, 0.050154321f, 0.0f, 27.137847f
};
static const float AI_POWER_SCALE[AI_POWER_FEATURES] = {
  0.70710678f, 0.70710678f, 0.70710678f, 0.70710678f, 317.22235f, 0.25790471f, 3.8356883f, 5.0462076f,
  6.0932418f, 11.855144f, 0.31271902f, 1.0f, 31.711215f
};
static const float AI_POWER_COEF[AI_POWER_FEATURES] = {
  0.12133215f, 1.7731703f, -0.028858723f, -0.87104818f, 22.247656f, 1.028228f, 1.28701f, 0.29873313f,
  -1.4241174f, -0.20577795f, 0.0099369486f, 0.0f, -11.070351f
};
static const float AI_POWER_INTERCEPT = 7.0539313f;

// Features: h_sin, h_cos, h2_sin, h2_cos, irradiance, irradiance2, ambient, humidity, panel, dust, rain_pct, rain_wet, light_pct, current_power, bus_v, current_a
static const float AI_NEXT_MEAN[AI_NEXT_FEATURES] = {
  -1.5077103e-17f, -4.7287277e-17f, 4.79726e-18f, -7.435753e-17f, 271.42593f, 0.17430206f, 32.067434f, 53.839506f,
  38.771671f, 28.403472f, 0.050154321f, 0.0f, 27.137847f, 7.0539313f, 9.0827623f, 0.42974614f
};
static const float AI_NEXT_SCALE[AI_NEXT_FEATURES] = {
  0.70710678f, 0.70710678f, 0.70710678f, 0.70710678f, 317.22235f, 0.25790471f, 3.8356883f, 5.0462076f,
  6.0932418f, 11.855144f, 0.31271902f, 1.0f, 31.711215f, 8.5891891f, 8.0405422f, 0.51666786f
};
static const float AI_NEXT_COEF[AI_NEXT_FEATURES] = {
  1.222028f, -0.67651148f, -0.80379003f, 0.045931615f, -1.6905622f, 0.66478191f, 0.51881876f, 0.087462483f,
  -0.7865907f, -0.003378466f, -0.16952909f, 0.0f, -0.50541344f, 4.3897044f, 0.23173734f, 5.6186643f
};
static const float AI_NEXT_INTERCEPT = 7.0539313f;

float aiSafeHourDecimal(const struct TimeFields &tf) {
  if (tf.synced && tf.hourDecimal >= 0.0f && tf.hourDecimal < 24.0f) return tf.hourDecimal;
  return fmodf((float)millis() / 3600000.0f, 24.0f);
}

float aiWrapHour(float h) {
  while (h < 0.0f) h += 24.0f;
  while (h >= 24.0f) h -= 24.0f;
  return h;
}

uint8_t aiSlotForHour(float h) {
  h = aiWrapHour(h);
  int slot = (int)floorf(h * 4.0f);
  if (slot < 0) slot = 0;
  if (slot > 95) slot = 95;
  return (uint8_t)slot;
}

float aiProfileValue(const float *arr, float h) {
  return arr[aiSlotForHour(h)];
}

void aiBaseFeatures(float hourDecimal, float irradiance, float ambient, float humidity, float panelTemp, float dustUg, float rainPct, float rainWet, float lightPct, float *x) {
  float a = AI_TWO_PI * aiWrapHour(hourDecimal) / 24.0f;
  x[0] = sinf(a);
  x[1] = cosf(a);
  x[2] = sinf(2.0f * a);
  x[3] = cosf(2.0f * a);
  x[4] = irradiance;
  float irrK = irradiance / 1000.0f;
  x[5] = irrK * irrK;
  x[6] = ambient;
  x[7] = humidity;
  x[8] = panelTemp;
  x[9] = dustUg;
  x[10] = rainPct;
  x[11] = rainWet;
  x[12] = lightPct;
}

float aiLinearPredict(const float *x, const float *mean, const float *scale, const float *coef, uint8_t n, float intercept) {
  float y = intercept;
  for (uint8_t i = 0; i < n; i++) {
    float s = scale[i];
    if (fabsf(s) < 0.000001f) s = 1.0f;
    y += coef[i] * ((x[i] - mean[i]) / s);
  }
  return y;
}

float aiPowerModelW(float hourDecimal, float irradiance, float ambient, float humidity, float panelTemp, float dustUg, float rainPct, float rainWet, float lightPct) {
  float x[AI_POWER_FEATURES];
  aiBaseFeatures(hourDecimal, irradiance, ambient, humidity, panelTemp, dustUg, rainPct, rainWet, lightPct, x);
  float y = aiLinearPredict(x, AI_POWER_MEAN, AI_POWER_SCALE, AI_POWER_COEF, AI_POWER_FEATURES, AI_POWER_INTERCEPT);
  return clampFloat(y, 0.0f, AI_PANEL_RATED_POWER_W);
}

float aiCurrentAmbientC(const SensorPayload &p, float fallbackHour) {
  float v = x100ToFloatOrNan(p.dhtTempC_x100);
  if (isnan(v) || isinf(v)) return aiProfileValue(AI_AMBIENT_PROFILE, fallbackHour);
  return v;
}

float aiCurrentHumidityPct(const SensorPayload &p, float fallbackHour) {
  float v = humidityToFloatOrNan(p);
  if (isnan(v) || isinf(v)) return aiProfileValue(AI_HUMIDITY_PROFILE, fallbackHour);
  return v;
}

float aiDaylightScale(const SensorPayload &p, float currentHour) {
  float profNow = aiProfileValue(AI_IRR_PROFILE, currentHour);
  float liveIrr = irradianceEstimateWm2(p);
  float scale = 1.0f;
  if (profNow > 80.0f && liveIrr > 5.0f) {
    scale = clampFloat(liveIrr / profNow, 0.45f, 1.25f);
  }
  if (rainDigitalWet(p)) scale *= 0.72f;
  return clampFloat(scale, 0.35f, 1.30f);
}

float aiForecastPowerAtHourW(const SensorPayload &p, const struct TimeFields &tf, float futureHour) {
  float currentHour = aiSafeHourDecimal(tf);
  float currentAmbient = aiCurrentAmbientC(p, currentHour);
  float currentHumidity = aiCurrentHumidityPct(p, currentHour);
  float ambientOffset = clampFloat(currentAmbient - aiProfileValue(AI_AMBIENT_PROFILE, currentHour), -7.0f, 7.0f);
  float humidityOffset = clampFloat(currentHumidity - aiProfileValue(AI_HUMIDITY_PROFILE, currentHour), -18.0f, 18.0f);

  float irr = aiProfileValue(AI_IRR_PROFILE, futureHour) * aiDaylightScale(p, currentHour);
  irr = clampFloat(irr, 0.0f, 1400.0f);
  float ambient = aiProfileValue(AI_AMBIENT_PROFILE, futureHour) + 0.55f * ambientOffset;
  float humidity = clampFloat(aiProfileValue(AI_HUMIDITY_PROFILE, futureHour) + 0.50f * humidityOffset, 0.0f, 100.0f);
  float panelTemp = ambient + (((PANEL_NOCT_C - 20.0f) / 800.0f) * irr);
  float dustUg = dustRawToUgM3(p.dustRaw);
  float rainPct = (float)rainWetPercent(p.rainAO);
  float rainWet = (float)rainDigitalWet(p);
  float lightPct = clampFloat((irr / IRRADIANCE_FULL_SCALE_WM2) * 100.0f, 0.0f, 100.0f);
  return aiPowerModelW(futureHour, irr, ambient, humidity, panelTemp, dustUg, rainPct, rainWet, lightPct);
}

float aiLiveModelPowerW(const SensorPayload &p, const struct TimeFields &tf) {
  float hour = aiSafeHourDecimal(tf);
  float irr = irradianceEstimateWm2(p);
  float ambient = aiCurrentAmbientC(p, hour);
  float humidity = aiCurrentHumidityPct(p, hour);
  float panelTemp = panelTempEstimateC(p);
  if (isnan(panelTemp) || isinf(panelTemp)) panelTemp = ambient + (((PANEL_NOCT_C - 20.0f) / 800.0f) * irr);
  float dustUg = dustRawToUgM3(p.dustRaw);
  float rainPct = (float)rainWetPercent(p.rainAO);
  float rainWet = (float)rainDigitalWet(p);
  float lightPct = lightAveragePct(p);
  return aiPowerModelW(hour, irr, ambient, humidity, panelTemp, dustUg, rainPct, rainWet, lightPct);
}

float aiNextHourDirectWh(const SensorPayload &p, const struct TimeFields &tf) {
  float hour = aiSafeHourDecimal(tf);
  float irr = irradianceEstimateWm2(p);
  float ambient = aiCurrentAmbientC(p, hour);
  float humidity = aiCurrentHumidityPct(p, hour);
  float panelTemp = panelTempEstimateC(p);
  if (isnan(panelTemp) || isinf(panelTemp)) panelTemp = ambient + (((PANEL_NOCT_C - 20.0f) / 800.0f) * irr);

  float x[AI_NEXT_FEATURES];
  aiBaseFeatures(hour, irr, ambient, humidity, panelTemp, dustRawToUgM3(p.dustRaw), (float)rainWetPercent(p.rainAO), (float)rainDigitalWet(p), lightAveragePct(p), x);
  x[13] = milliWattsToWatts(p.power_mW);
  x[14] = milliVoltsToVolts(p.bus_mV);
  x[15] = milliAmpsToAmps(p.current_mA);

  float wh = aiLinearPredict(x, AI_NEXT_MEAN, AI_NEXT_SCALE, AI_NEXT_COEF, AI_NEXT_FEATURES, AI_NEXT_INTERCEPT);
  return clampFloat(wh, 0.0f, AI_PANEL_RATED_POWER_W);
}

float aiNextHourProfileWh(const SensorPayload &p, const struct TimeFields &tf) {
  float startHour = aiSafeHourDecimal(tf);
  float wh = 0.0f;
  for (uint8_t i = 1; i <= 4; i++) {
    wh += aiForecastPowerAtHourW(p, tf, startHour + 0.25f * (float)i) * 0.25f;
  }
  return clampFloat(wh, 0.0f, AI_PANEL_RATED_POWER_W);
}

float aiPredictNextHourWh(const SensorPayload &p, const struct TimeFields &tf) {
  float profileWh = aiNextHourProfileWh(p, tf);
  if (p.sensorFlags & SFLAG_INA_OK) {
    float directWh = aiNextHourDirectWh(p, tf);
    return clampFloat(0.65f * directWh + 0.35f * profileWh, 0.0f, AI_PANEL_RATED_POWER_W);
  }
  return profileWh;
}

float aiPredictTomorrowWh(const SensorPayload &p, const struct TimeFields &tf) {
  float wh = 0.0f;
  for (uint8_t slot = 0; slot < AI_SLOT_COUNT; slot++) {
    float hour = (float)slot * 0.25f;
    wh += aiForecastPowerAtHourW(p, tf, hour) * 0.25f;
  }
  return clampFloat(wh, 0.0f, AI_PANEL_RATED_POWER_W * 24.0f);
}

float aiConfidencePct(const SensorPayload &p, const struct TimeFields &tf) {
  float c = 93.0f;
  if (!latestValid) c -= 35.0f;
  if (!(p.sensorFlags & SFLAG_DHT_OK)) c -= 12.0f;
  if (!(p.sensorFlags & SFLAG_INA_OK)) c -= 6.0f;
  if (p.sensorFlags & SFLAG_ADC_EXTREME) c -= 22.0f;
  if (!tf.synced) c -= 8.0f;
  if (rainDigitalWet(p)) c -= 5.0f;
  if (dustRawToUgM3(p.dustRaw) > 80.0f) c -= 6.0f;
  return clampFloat(c, 30.0f, 98.0f);
}


// ---------------- Pro forecast analytics / weather integration ----------------
struct DayEnergySummary {
  float wh;
  uint16_t samples;
  bool valid;
  String date;
};

struct AiForecastSummary {
  float normalWh;
  float bestWh;
  float worstWh;
  float baselineWh;
  float gainLossPct;
  float lossGainWh;
  float vsYesterdayPct;
  float uncertaintyPct;
  float confidencePct;
  bool weatherUsed;
  float weatherIrrAvg;
  float weatherTempAvg;
  float weatherHumidityAvg;
  float weatherCloudAvg;
  float weatherRainMax;
  float weatherScalePct;
  float weatherLossPct;
  float dustLossPct;
  float heatLossPct;
  float rainLossPct;
  float trackingLossPct;
  String primaryFactor;
  String factorSummary;
  String recommendation;
};

String jsonEscape(String s) {
  s.replace("\\", "\\\\");
  s.replace("\"", "\\\"");
  s.replace("\r", " ");
  s.replace("\n", " ");
  return s;
}

String csvGetField(const String &line, uint8_t index) {
  int start = 0;
  for (uint8_t i = 0; i < index; i++) {
    start = line.indexOf(',', start);
    if (start < 0) return "";
    start++;
  }
  int end = line.indexOf(',', start);
  if (end < 0) end = line.length();
  String out = line.substring(start, end);
  out.trim();
  return out;
}

String dateDaysFromNow(int days) {
  time_t now = time(nullptr);
  if (now < 1700000000) return "";
  now += (time_t)days * 86400;
  struct tm tmNow;
  localtime_r(&now, &tmNow);
  char buf[16];
  strftime(buf, sizeof(buf), "%Y-%m-%d", &tmNow);
  return String(buf);
}

struct DayEnergySummary readEnergyForDate(const String &targetDate) {
  struct DayEnergySummary out{};
  out.wh = NAN;
  out.samples = 0;
  out.valid = false;
  out.date = targetDate.length() ? targetDate : "NA";
  if (!targetDate.length() || !LittleFS.exists(LOG_PATH)) return out;

  File f = LittleFS.open(LOG_PATH, "r");
  if (!f) return out;
  if (f.available()) f.readStringUntil('\n'); // header
  float wh = 0.0f;
  uint16_t samples = 0;
  while (f.available()) {
    String line = f.readStringUntil('\n');
    line.trim();
    if (line.length() < 20) continue;
    String d = csvGetField(line, 2);
    if (d != targetDate) continue;
    String pwr = csvGetField(line, 37);
    if (!pwr.length()) continue;
    float powerW = pwr.toFloat();
    if (isnan(powerW) || isinf(powerW) || powerW < 0.0f) continue;
    wh += powerW * 0.25f; // logger period is 15 minutes
    samples++;
  }
  f.close();
  if (samples > 0) {
    out.wh = wh;
    out.samples = samples;
    out.valid = true;
  }
  return out;
}


struct DayEnergySummary excelSeedLastDayEnergy() {
  struct DayEnergySummary out{};
  out.wh = EXCEL_SEED_LAST_DAY_WH;
  out.samples = EXCEL_SEED_LAST_DAY_SAMPLES;
  out.valid = true;
  out.date = String(EXCEL_SEED_LAST_DAY_DATE);
  return out;
}

struct RetrainDatasetStatus {
  uint32_t rows;
  uint32_t syncedRows;
  uint16_t uniqueDates;
  String firstDate;
  String lastDate;
  bool enough;
  bool timeReady;
  String message;
};

struct RetrainDatasetStatus getRetrainDatasetStatus() {
  struct RetrainDatasetStatus st{};
  struct TimeFields tf = getTimeFields();
  st.timeReady = tf.synced;
  st.rows = 0;
  st.syncedRows = 0;
  st.uniqueDates = 0;
  st.firstDate = "NA";
  st.lastDate = "NA";
  st.enough = false;

  if (!LittleFS.exists(LOG_PATH)) {
    st.message = "CSV log is empty. Keep the device online and logging.";
    return st;
  }
  File f = LittleFS.open(LOG_PATH, "r");
  if (!f) {
    st.message = "CSV log could not be opened.";
    return st;
  }
  if (f.available()) f.readStringUntil('\n'); // header
  String previousDate = "";
  while (f.available()) {
    String line = f.readStringUntil('\n');
    line.trim();
    if (line.length() < 20) continue;
    String d = csvGetField(line, 2);
    if (!d.length() || d == "NA" || d == "date_yyyy_mm_dd") continue;
    st.rows++;
    String synced = csvGetField(line, 7);
    if (synced == "1") st.syncedRows++;
    if (st.firstDate == "NA") st.firstDate = d;
    st.lastDate = d;
    if (d != previousDate) {
      st.uniqueDates++;
      previousDate = d;
    }
  }
  f.close();

  bool enoughRows = st.rows >= RETRAIN_MIN_ROWS;
  bool enoughDays = st.uniqueDates >= RETRAIN_MIN_DAYS;
  bool syncedMostly = (st.rows > 0) && ((st.syncedRows * 100UL) >= (st.rows * 90UL));
  st.enough = enoughRows && enoughDays && syncedMostly && st.timeReady;
  if (!st.timeReady) st.message = "NTP time is not synced. Connect the ESP32 to router WiFi with internet first.";
  else if (!enoughRows) st.message = "Not enough CSV rows yet. Minimum is 288 valid 15-minute rows.";
  else if (!enoughDays) st.message = "CSV must cover at least 3 different dates.";
  else if (!syncedMostly) st.message = "Too many rows were logged without NTP time. Keep the board online and logging.";
  else st.message = "Dataset is ready for Python retraining.";
  return st;
}

void requestNtpSync() {
  if (WiFi.status() == WL_CONNECTED) {
    configTzTime(TZ_INFO, "pool.ntp.org", "time.google.com", "time.nist.gov");
  }
}

bool parseJsonFloatArray(const String &json, const char *key, float *out, uint8_t maxCount, uint8_t &count) {
  count = 0;
  String pattern = String("\"") + key + "\":[";
  int start = json.indexOf(pattern);
  if (start < 0) return false;
  start += pattern.length();
  int end = json.indexOf(']', start);
  if (end < 0) return false;
  int pos = start;
  while (pos < end && count < maxCount) {
    int comma = json.indexOf(',', pos);
    if (comma < 0 || comma > end) comma = end;
    String tok = json.substring(pos, comma);
    tok.trim();
    if (tok == "null" || tok.length() == 0) out[count] = NAN;
    else out[count] = tok.toFloat();
    count++;
    pos = comma + 1;
  }
  return count > 0;
}

bool updateWeatherForecastIfNeeded(bool force) {
  if (!WEATHER_FORECAST_ENABLED) {
    weatherOK = false;
    weatherStatus = "Weather disabled in firmware";
    return false;
  }
  uint32_t nowMs = millis();
  if (!force && weatherLastFetchMs != 0 && nowMs - weatherLastFetchMs < WEATHER_UPDATE_PERIOD_MS) return weatherOK;
  weatherLastFetchMs = nowMs;
  if (WiFi.status() != WL_CONNECTED) {
    weatherOK = false;
    weatherStatus = "Router internet not connected";
    return false;
  }

  String url = String("https://api.open-meteo.com/v1/forecast?latitude=") + String(SITE_LATITUDE, 4) +
               "&longitude=" + String(SITE_LONGITUDE, 4) +
               "&hourly=temperature_2m,relative_humidity_2m,precipitation_probability,cloud_cover,shortwave_radiation&forecast_days=2&timezone=auto";

  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(9000);
  if (!http.begin(client, url)) {
    weatherOK = false;
    weatherStatus = "Weather HTTP begin failed";
    return false;
  }
  int code = http.GET();
  weatherLastHttpCode = code;
  if (code != HTTP_CODE_OK) {
    weatherOK = false;
    weatherStatus = String("Open-Meteo HTTP ") + String(code);
    http.end();
    return false;
  }
  String body = http.getString();
  http.end();

  uint8_t cIrr = 0, cTemp = 0, cHum = 0, cCloud = 0, cRain = 0;
  bool okIrr = parseJsonFloatArray(body, "shortwave_radiation", weatherShortwave, WEATHER_HOURLY_MAX, cIrr);
  parseJsonFloatArray(body, "temperature_2m", weatherTemp, WEATHER_HOURLY_MAX, cTemp);
  parseJsonFloatArray(body, "relative_humidity_2m", weatherHumidity, WEATHER_HOURLY_MAX, cHum);
  parseJsonFloatArray(body, "cloud_cover", weatherCloud, WEATHER_HOURLY_MAX, cCloud);
  parseJsonFloatArray(body, "precipitation_probability", weatherRainProb, WEATHER_HOURLY_MAX, cRain);

  weatherCount = cIrr;
  weatherOK = okIrr && weatherCount >= 36;
  weatherStatus = weatherOK ? "OK - Open-Meteo forecast loaded" : "Open-Meteo parse failed";
  return weatherOK;
}

bool weatherValueAtTomorrowHour(const float *arr, float hour, float &out) {
  if (!weatherOK || weatherCount == 0) return false;
  int idx = 24 + (int)floorf(aiWrapHour(hour));
  if (idx < 0 || idx >= weatherCount) return false;
  out = arr[idx];
  if (isnan(out) || isinf(out)) return false;
  return true;
}

void weatherTomorrowStats(float &irrAvg, float &tempAvg, float &humAvg, float &cloudAvg, float &rainMax) {
  irrAvg = tempAvg = humAvg = cloudAvg = NAN;
  rainMax = NAN;
  if (!weatherOK) return;
  float irrS = 0, tempS = 0, humS = 0, cloudS = 0, rainM = 0;
  uint8_t irrN = 0, tempN = 0, humN = 0, cloudN = 0, rainN = 0;
  for (uint8_t i = 24; i < weatherCount && i < 48; i++) {
    if (!isnan(weatherShortwave[i])) { irrS += weatherShortwave[i]; irrN++; }
    if (!isnan(weatherTemp[i])) { tempS += weatherTemp[i]; tempN++; }
    if (!isnan(weatherHumidity[i])) { humS += weatherHumidity[i]; humN++; }
    if (!isnan(weatherCloud[i])) { cloudS += weatherCloud[i]; cloudN++; }
    if (!isnan(weatherRainProb[i])) { if (weatherRainProb[i] > rainM) rainM = weatherRainProb[i]; rainN++; }
  }
  if (irrN) irrAvg = irrS / irrN;
  if (tempN) tempAvg = tempS / tempN;
  if (humN) humAvg = humS / humN;
  if (cloudN) cloudAvg = cloudS / cloudN;
  if (rainN) rainMax = rainM;
}

float aiTrainingNormalDailyWh() {
  float wh = 0.0f;
  for (uint8_t slot = 0; slot < AI_SLOT_COUNT; slot++) {
    float hour = (float)slot * 0.25f;
    float irr = aiProfileValue(AI_IRR_PROFILE, hour);
    float amb = aiProfileValue(AI_AMBIENT_PROFILE, hour);
    float hum = aiProfileValue(AI_HUMIDITY_PROFILE, hour);
    float panel = amb + (((PANEL_NOCT_C - 20.0f) / 800.0f) * irr);
    float lightPct = clampFloat((irr / IRRADIANCE_FULL_SCALE_WM2) * 100.0f, 0.0f, 100.0f);
    wh += aiPowerModelW(hour, irr, amb, hum, panel, 28.0f, 0.0f, 0.0f, lightPct) * 0.25f;
  }
  return clampFloat(wh, 0.0f, AI_PANEL_RATED_POWER_W * 24.0f);
}

float aiForecastPowerAtHourWeatherW(const SensorPayload &p, const struct TimeFields &tf, float futureHour) {
  float irr;
  if (!weatherValueAtTomorrowHour(weatherShortwave, futureHour, irr)) {
    return aiForecastPowerAtHourW(p, tf, futureHour);
  }
  irr = clampFloat(irr, 0.0f, 1400.0f);
  float ambient;
  if (!weatherValueAtTomorrowHour(weatherTemp, futureHour, ambient)) ambient = aiProfileValue(AI_AMBIENT_PROFILE, futureHour);
  float humidity;
  if (!weatherValueAtTomorrowHour(weatherHumidity, futureHour, humidity)) humidity = aiProfileValue(AI_HUMIDITY_PROFILE, futureHour);
  float rainProb;
  if (!weatherValueAtTomorrowHour(weatherRainProb, futureHour, rainProb)) rainProb = (float)rainWetPercent(p.rainAO);
  float panelTemp = ambient + (((PANEL_NOCT_C - 20.0f) / 800.0f) * irr);
  float dustUg = dustRawToUgM3(p.dustRaw);
  float rainWet = (rainProb >= 60.0f || rainDigitalWet(p)) ? 1.0f : 0.0f;
  float lightPct = clampFloat((irr / IRRADIANCE_FULL_SCALE_WM2) * 100.0f, 0.0f, 100.0f);
  return aiPowerModelW(futureHour, irr, ambient, humidity, panelTemp, dustUg, rainProb, rainWet, lightPct);
}

float aiPredictTomorrowNormalWh(const SensorPayload &p, const struct TimeFields &tf) {
  float wh = 0.0f;
  for (uint8_t slot = 0; slot < AI_SLOT_COUNT; slot++) {
    float hour = (float)slot * 0.25f;
    wh += aiForecastPowerAtHourWeatherW(p, tf, hour) * 0.25f;
  }
  return clampFloat(wh, 0.0f, AI_PANEL_RATED_POWER_W * 24.0f);
}

struct AiForecastSummary buildAiForecastSummary(const SensorPayload &p, const struct TimeFields &tf, const struct DayEnergySummary &yesterday) {
  struct AiForecastSummary s{};
  s.normalWh = aiPredictTomorrowNormalWh(p, tf);
  s.baselineWh = aiTrainingNormalDailyWh();
  s.weatherUsed = weatherOK;
  weatherTomorrowStats(s.weatherIrrAvg, s.weatherTempAvg, s.weatherHumidityAvg, s.weatherCloudAvg, s.weatherRainMax);

  float profileIrr = 0.0f;
  for (uint8_t i = 0; i < AI_SLOT_COUNT; i++) profileIrr += AI_IRR_PROFILE[i];
  profileIrr /= AI_SLOT_COUNT;
  s.weatherScalePct = (s.weatherUsed && profileIrr > 1.0f && !isnan(s.weatherIrrAvg)) ? (s.weatherIrrAvg / profileIrr) * 100.0f : NAN;
  s.weatherLossPct = (s.weatherUsed && !isnan(s.weatherScalePct)) ? clampFloat(100.0f - s.weatherScalePct, 0.0f, 45.0f) : 0.0f;

  float dustUg = dustRawToUgM3(p.dustRaw);
  s.dustLossPct = clampFloat((dustUg - 45.0f) * 0.12f, 0.0f, 14.0f);
  float panelNow = panelTempEstimateC(p);
  if (isnan(panelNow) || isinf(panelNow)) panelNow = aiCurrentAmbientC(p, aiSafeHourDecimal(tf));
  s.heatLossPct = clampFloat((panelNow - 50.0f) * 0.40f, 0.0f, 12.0f);
  s.rainLossPct = s.weatherUsed && !isnan(s.weatherRainMax) ? clampFloat(s.weatherRainMax * 0.18f, 0.0f, 18.0f) : (rainDigitalWet(p) ? 12.0f : 0.0f);
  bool link = (lastAckMs != 0 && millis() - lastAckMs < 2500);
  s.trackingLossPct = (!link || (haveActStatus && !latestAct.autoMode)) ? 7.0f : 0.0f;

  s.uncertaintyPct = 10.0f;
  if (!s.weatherUsed) s.uncertaintyPct += 8.0f;
  if (!(p.sensorFlags & SFLAG_DHT_OK)) s.uncertaintyPct += 5.0f;
  if (!(p.sensorFlags & SFLAG_INA_OK)) s.uncertaintyPct += 4.0f;
  if (s.weatherLossPct > 20.0f) s.uncertaintyPct += 4.0f;
  if (s.rainLossPct > 8.0f) s.uncertaintyPct += 4.0f;
  s.uncertaintyPct = clampFloat(s.uncertaintyPct, 8.0f, 32.0f);
  s.bestWh = clampFloat(s.normalWh * (1.0f + s.uncertaintyPct / 100.0f), 0.0f, AI_PANEL_RATED_POWER_W * 24.0f);
  s.worstWh = clampFloat(s.normalWh * (1.0f - s.uncertaintyPct / 100.0f), 0.0f, AI_PANEL_RATED_POWER_W * 24.0f);
  s.lossGainWh = s.normalWh - s.baselineWh;
  s.gainLossPct = (s.baselineWh > 1.0f) ? (s.lossGainWh / s.baselineWh) * 100.0f : NAN;
  s.vsYesterdayPct = (yesterday.valid && yesterday.wh > 1.0f) ? ((s.normalWh - yesterday.wh) / yesterday.wh) * 100.0f : NAN;
  s.confidencePct = clampFloat(aiConfidencePct(p, tf) - (s.uncertaintyPct - 10.0f) * 0.7f, 25.0f, 98.0f);

  float maxLoss = s.weatherLossPct;
  s.primaryFactor = "Low radiation / clouds";
  if (s.rainLossPct > maxLoss) { maxLoss = s.rainLossPct; s.primaryFactor = "Rain probability / wet panel"; }
  if (s.dustLossPct > maxLoss) { maxLoss = s.dustLossPct; s.primaryFactor = "Dust on optical path / panel"; }
  if (s.heatLossPct > maxLoss) { maxLoss = s.heatLossPct; s.primaryFactor = "High panel temperature"; }
  if (s.trackingLossPct > maxLoss) { maxLoss = s.trackingLossPct; s.primaryFactor = "Tracking not optimal"; }
  if (maxLoss < 2.0f) s.primaryFactor = "Near-normal conditions";

  s.factorSummary = String("Weather loss ") + String(s.weatherLossPct, 1) + "% | Rain " + String(s.rainLossPct, 1) +
                    "% | Dust " + String(s.dustLossPct, 1) + "% | Heat " + String(s.heatLossPct, 1) +
                    "% | Tracking " + String(s.trackingLossPct, 1) + "%";
  if (s.primaryFactor == "Dust on optical path / panel") s.recommendation = "Run cleaning cycle and check dust sensor calibration.";
  else if (s.primaryFactor == "Rain probability / wet panel") s.recommendation = "Keep tracker safe; expect lower production while panel is wet/cloudy.";
  else if (s.primaryFactor == "Tracking not optimal") s.recommendation = "Enable AUTO tracking and confirm UART actuator link.";
  else if (s.primaryFactor == "High panel temperature") s.recommendation = "Check ventilation and panel mounting; heat reduces voltage.";
  else if (s.primaryFactor == "Low radiation / clouds") s.recommendation = "Forecast depends on tomorrow radiation/clouds; update weather when WiFi is online.";
  else s.recommendation = "Conditions look normal; keep logging for better retraining.";
  return s;
}

String nowStamp() {
  struct TimeFields tf = getTimeFields();
  if (tf.synced) return tf.date + " " + tf.timeOfDay;
  return tf.iso;
}

void ensureLogHeader() {
  bool rewrite = true;
  if (LittleFS.exists(LOG_PATH)) {
    File old = LittleFS.open(LOG_PATH, "r");
    if (old) {
      String firstLine = old.readStringUntil('\n');
      firstLine.trim();
      rewrite = (firstLine != String(CSV_HEADER));
      old.close();
    }
    if (rewrite) {
      LittleFS.remove("/log_legacy.csv");
      LittleFS.rename(LOG_PATH, "/log_legacy.csv");
    }
  }

  if (rewrite || !LittleFS.exists(LOG_PATH)) {
    File f = LittleFS.open(LOG_PATH, "w");
    if (f) {
      f.println(CSV_HEADER);
      f.close();
    }
  }
}

void rotateLogIfNeeded() {
  File f = LittleFS.open(LOG_PATH, "r");
  if (!f) return;
  size_t sz = f.size();
  f.close();
  if (sz > LOG_MAX_BYTES) {
    LittleFS.remove("/log_old.csv");
    LittleFS.rename(LOG_PATH, "/log_old.csv");
    ensureLogHeader();
  }
}

void appendCsvRow(const SensorPayload &p) {
  ensureLogHeader();
  rotateLogIfNeeded();
  File f = LittleFS.open(LOG_PATH, "a");
  if (!f) return;

  struct TimeFields tf = getTimeFields();
  bool link = (lastAckMs != 0 && millis() - lastAckMs < 2500);
  const bool dhtOK = dhtValueOK(p);
  const bool inaGood = (p.sensorFlags & SFLAG_INA_OK);
  const bool adcExtreme = (p.sensorFlags & SFLAG_ADC_EXTREME);
  const float aiNowPowerW = aiLiveModelPowerW(p, tf);
  const float aiNextHourWh = aiPredictNextHourWh(p, tf);
  const String yDate = dateDaysFromNow(-1);
  const struct DayEnergySummary ySummary = readEnergyForDate(yDate);
  const struct AiForecastSummary aiSummary = buildAiForecastSummary(p, tf, ySummary);
  const float aiTomorrowWh = aiSummary.normalWh;
  const float aiConfidence = aiSummary.confidencePct;

  f.print(CSV_SCHEMA_VERSION); f.print(',');
  f.print(tf.iso); f.print(',');
  f.print(tf.date); f.print(',');
  f.print(tf.timeOfDay); f.print(',');
  f.print(tf.hour); f.print(',');
  csvPrintFloat(f, tf.hourDecimal, 4); f.print(',');
  f.print(tf.unixEpoch); f.print(',');
  f.print(tf.synced ? 1 : 0); f.print(',');
  f.print(p.uptime_ms / 1000); f.print(',');
  f.print(p.seq); f.print(',');

  csvPrintFloat(f, x100ToFloatOrNan(p.dhtTempC_x100), 2); f.print(',');
  csvPrintFloat(f, humidityToFloatOrNan(p), 2); f.print(',');
  csvPrintFloat(f, panelTempEstimateC(p), 2); f.print(',');
  f.print(PANEL_TEMP_SOURCE_CALCULATED_FROM_AMBIENT); f.print(',');
  f.print(dhtOK ? 1 : 0); f.print(',');

  csvPrintFloat(f, irradianceEstimateWm2(p), 2); f.print(',');
  f.print(IRRADIANCE_SOURCE_ESTIMATED_LDR); f.print(',');
  csvPrintFloat(f, lightAverageRaw(p), 2); f.print(',');
  csvPrintFloat(f, lightAveragePct(p), 2); f.print(',');
  f.print(p.adcTL); f.print(','); f.print(p.adcTR); f.print(','); f.print(p.adcBL); f.print(','); f.print(p.adcBR); f.print(',');
  f.print(p.lightErrH); f.print(','); f.print(p.lightErrV); f.print(',');

  f.print(p.rainAO); f.print(',');
  f.print(rainWetPercent(p.rainAO)); f.print(',');
  f.print(rainDigitalWet(p)); f.print(',');
  f.print(p.rainDO); f.print(',');

  f.print(p.dustRaw); f.print(',');
  csvPrintFloat(f, rawToVolts(p.dustRaw), 4); f.print(',');
  csvPrintFloat(f, dustRawToUgM3(p.dustRaw), 2); f.print(',');

  f.print(p.pir1 ? 1 : 0); f.print(',');
  f.print(p.pir2 ? 1 : 0); f.print(',');
  f.print(tiltActive(p)); f.print(',');

  csvPrintFloat(f, milliVoltsToVolts(p.bus_mV), 3); f.print(',');
  csvPrintFloat(f, milliAmpsToAmps(p.current_mA), 3); f.print(',');
  csvPrintFloat(f, milliWattsToWatts(p.power_mW), 3); f.print(',');
  f.print(inaGood ? 1 : 0); f.print(',');

  f.print(p.sensorFlags); f.print(',');
  f.print(adcExtreme ? 1 : 0); f.print(',');

  f.print(link ? 1 : 0); f.print(',');
  f.print(haveActStatus ? latestAct.armed : 0); f.print(',');
  f.print(haveActStatus ? latestAct.autoMode : 0); f.print(',');
  f.print(haveActStatus ? latestAct.motorDuty : 0); f.print(',');
  f.print(haveActStatus ? latestAct.servoDeg : 0); f.print(',');
  f.print(haveActStatus ? latestAct.pumpOn : 0); f.print(',');
  f.print(haveActStatus ? latestAct.cleaningActive : 0); f.print(',');
  f.print(haveActStatus ? latestAct.limitActive : 0); f.print(',');
  f.print(haveActStatus ? latestAct.faultCode : 99); f.print(',');
  csvPrintFloat(f, aiNowPowerW, 3); f.print(',');
  csvPrintFloat(f, aiNextHourWh, 3); f.print(',');
  csvPrintFloat(f, aiTomorrowWh, 3); f.print(',');
  csvPrintFloat(f, aiTomorrowWh / 1000.0f, 4); f.print(',');
  csvPrintFloat(f, aiConfidence, 1); f.print(',');
  csvPrintFloat(f, aiSummary.bestWh, 3); f.print(',');
  csvPrintFloat(f, aiSummary.normalWh, 3); f.print(',');
  csvPrintFloat(f, aiSummary.worstWh, 3); f.print(',');
  csvPrintFloat(f, aiSummary.baselineWh, 3); f.print(',');
  csvPrintFloat(f, aiSummary.gainLossPct, 2); f.print(',');
  csvPrintFloat(f, aiSummary.uncertaintyPct, 1); f.print(',');
  f.print(aiSummary.weatherUsed ? 1 : 0); f.print(',');
  csvPrintFloat(f, aiSummary.weatherIrrAvg, 2); f.print(',');
  csvPrintFloat(f, aiSummary.weatherTempAvg, 2); f.print(',');
  csvPrintFloat(f, aiSummary.weatherCloudAvg, 2); f.print(',');
  csvPrintFloat(f, aiSummary.weatherRainMax, 2); f.println();

  f.close();
  Serial.println(F("AI-ready CSV log row saved"));
}

// ---------------- Web UI ----------------
String fmtTemp(int16_t x100) { if (x100 == INT16_MIN) return "ERR"; return String(x100 / 100.0f, 2); }
String fmtRh(const SensorPayload &p) { if (!(p.sensorFlags & SFLAG_DHT_OK)) return "ERR"; return String(p.dhtHumidity_x100 / 100.0f, 1); }
String okMiss(bool ok) { return ok ? "OK" : "Missing"; }

void handleApi() {
  SensorPayload &p = latest;
  bool link = (lastAckMs != 0 && millis() - lastAckMs < 2500);
  struct TimeFields tf = getTimeFields();
  float irr = irradianceEstimateWm2(p);
  float panelEst = panelTempEstimateC(p);
  float lightAvg = lightAverageRaw(p);
  float lightPct = lightAveragePct(p);
  const float aiNowPowerW = aiLiveModelPowerW(p, tf);
  const float aiNextHourWh = aiPredictNextHourWh(p, tf);
  updateWeatherForecastIfNeeded(false);
  const String yesterdayDate = dateDaysFromNow(-1);
  const String todayDate = dateDaysFromNow(0);
  struct DayEnergySummary yesterday = readEnergyForDate(yesterdayDate);
  String actualYesterdaySource = "csv";
  if (!yesterday.valid) {
    yesterday = excelSeedLastDayEnergy();
    actualYesterdaySource = EXCEL_SEED_SOURCE;
  }
  const struct DayEnergySummary today = readEnergyForDate(todayDate);
  const struct AiForecastSummary aiSummary = buildAiForecastSummary(p, tf, yesterday);
  const struct RetrainDatasetStatus retrainStatus = getRetrainDatasetStatus();
  const float aiTomorrowWh = aiSummary.normalWh;
  const float aiConfidence = aiSummary.confidencePct;

  String json = "{";
  json += "\"valid\":" + String(latestValid ? 1 : 0) + ",";
  json += "\"schema\":" + String(CSV_SCHEMA_VERSION) + ",";
  json += "\"timestamp\":\"" + tf.iso + "\",";
  json += "\"date\":\"" + tf.date + "\",";
  json += "\"time\":\"" + tf.timeOfDay + "\",";
  json += "\"hour\":" + String(tf.hour) + ",";
  json += "\"hourDecimal\":" + fmtFloatForJson(tf.hourDecimal, 4) + ",";
  json += "\"timeSynced\":" + String(tf.synced ? 1 : 0) + ",";
  json += "\"ap_ip\":\"" + WiFi.softAPIP().toString() + "\",";
  json += "\"sta_ip\":\"" + staIP + "\",";
  json += "\"seq\":" + String(p.seq) + ",";
  json += "\"uptime\":" + String(millis()/1000) + ",";
  json += "\"tl\":" + String(p.adcTL) + ",\"tr\":" + String(p.adcTR) + ",\"bl\":" + String(p.adcBL) + ",\"br\":" + String(p.adcBR) + ",";
  json += "\"lightAvg\":" + fmtFloatForJson(lightAvg, 2) + ",\"lightPct\":" + fmtFloatForJson(lightPct, 2) + ",";
  json += "\"irradiance\":" + fmtFloatForJson(irr, 2) + ",\"irradianceSource\":" + String(IRRADIANCE_SOURCE_ESTIMATED_LDR) + ",";
  json += "\"errH\":" + String(p.lightErrH) + ",\"errV\":" + String(p.lightErrV) + ",";
  json += "\"rainAO\":" + String(p.rainAO) + ",\"rainPct\":" + String(rainWetPercent(p.rainAO)) + ",\"rainWet\":" + String(rainDigitalWet(p)) + ",\"rainDO\":" + String(p.rainDO) + ",";
  json += "\"dust\":" + String(p.dustRaw) + ",\"dustV\":" + fmtFloatForJson(rawToVolts(p.dustRaw), 4) + ",\"dustUg\":" + fmtFloatForJson(dustRawToUgM3(p.dustRaw),1) + ",";
  json += "\"pir1\":" + String(p.pir1 ? 1 : 0) + ",\"pir2\":" + String(p.pir2 ? 1 : 0) + ",\"tilt\":" + String(tiltActive(p)) + ",";
  json += "\"panel\":" + fmtFloatForJson(panelEst, 2) + ",\"panelSource\":" + String(PANEL_TEMP_SOURCE_CALCULATED_FROM_AMBIENT) + ",";
  json += "\"air\":\"" + fmtTemp(p.dhtTempC_x100) + "\",\"airNum\":" + fmtFloatForJson(x100ToFloatOrNan(p.dhtTempC_x100), 2) + ",\"rh\":\"" + fmtRh(p) + "\",\"rhNum\":" + fmtFloatForJson(humidityToFloatOrNan(p), 2) + ",";
  json += "\"busV\":" + String(milliVoltsToVolts(p.bus_mV),3) + ",\"currentA\":" + String(milliAmpsToAmps(p.current_mA),3) + ",\"powerW\":" + String(milliWattsToWatts(p.power_mW),3) + ",";
  json += "\"aiModel\":\"" + String(AI_MODEL_NAME) + "\",";
  json += "\"aiNowPowerW\":" + fmtFloatForJson(aiNowPowerW, 3) + ",";
  json += "\"aiNextHourWh\":" + fmtFloatForJson(aiNextHourWh, 3) + ",";
  json += "\"aiTomorrowWh\":" + fmtFloatForJson(aiTomorrowWh, 3) + ",";
  json += "\"aiTomorrowKWh\":" + fmtFloatForJson(aiTomorrowWh / 1000.0f, 4) + ",";
  json += "\"aiConfidence\":" + fmtFloatForJson(aiConfidence, 1) + ",";
  json += "\"aiTomorrowBestWh\":" + fmtFloatForJson(aiSummary.bestWh, 3) + ",";
  json += "\"aiTomorrowBestKWh\":" + fmtFloatForJson(aiSummary.bestWh / 1000.0f, 4) + ",";
  json += "\"aiTomorrowNormalWh\":" + fmtFloatForJson(aiSummary.normalWh, 3) + ",";
  json += "\"aiTomorrowNormalKWh\":" + fmtFloatForJson(aiSummary.normalWh / 1000.0f, 4) + ",";
  json += "\"aiTomorrowWorstWh\":" + fmtFloatForJson(aiSummary.worstWh, 3) + ",";
  json += "\"aiTomorrowWorstKWh\":" + fmtFloatForJson(aiSummary.worstWh / 1000.0f, 4) + ",";
  json += "\"aiBaselineWh\":" + fmtFloatForJson(aiSummary.baselineWh, 3) + ",";
  json += "\"aiGainLossWh\":" + fmtFloatForJson(aiSummary.lossGainWh, 3) + ",";
  json += "\"aiGainLossPct\":" + fmtFloatForJson(aiSummary.gainLossPct, 2) + ",";
  json += "\"aiVsYesterdayPct\":" + fmtFloatForJson(aiSummary.vsYesterdayPct, 2) + ",";
  json += "\"aiUncertaintyPct\":" + fmtFloatForJson(aiSummary.uncertaintyPct, 1) + ",";
  json += "\"aiPrimaryFactor\":\"" + jsonEscape(aiSummary.primaryFactor) + "\",";
  json += "\"aiFactorSummary\":\"" + jsonEscape(aiSummary.factorSummary) + "\",";
  json += "\"aiRecommendation\":\"" + jsonEscape(aiSummary.recommendation) + "\",";
  json += "\"actualYesterdayWh\":" + fmtFloatForJson(yesterday.wh, 3) + ",";
  json += "\"actualYesterdayKWh\":" + fmtFloatForJson(yesterday.wh / 1000.0f, 4) + ",";
  json += "\"actualYesterdaySamples\":" + String(yesterday.samples) + ",";
  json += "\"actualYesterdayDate\":\"" + jsonEscape(yesterday.date) + "\",";
  json += "\"actualTodayWh\":" + fmtFloatForJson(today.wh, 3) + ",";
  json += "\"actualTodaySamples\":" + String(today.samples) + ",";
  json += "\"weatherEnabled\":" + String(WEATHER_FORECAST_ENABLED ? 1 : 0) + ",";
  json += "\"weatherUsed\":" + String(aiSummary.weatherUsed ? 1 : 0) + ",";
  json += "\"weatherStatus\":\"" + jsonEscape(weatherStatus) + "\",";
  json += "\"weatherHttp\":" + String(weatherLastHttpCode) + ",";
  json += "\"weatherLat\":" + fmtFloatForJson(SITE_LATITUDE, 4) + ",";
  json += "\"weatherLon\":" + fmtFloatForJson(SITE_LONGITUDE, 4) + ",";
  json += "\"weatherIrrAvg\":" + fmtFloatForJson(aiSummary.weatherIrrAvg, 2) + ",";
  json += "\"weatherTempAvg\":" + fmtFloatForJson(aiSummary.weatherTempAvg, 2) + ",";
  json += "\"weatherHumidityAvg\":" + fmtFloatForJson(aiSummary.weatherHumidityAvg, 2) + ",";
  json += "\"weatherCloudAvg\":" + fmtFloatForJson(aiSummary.weatherCloudAvg, 2) + ",";
  json += "\"weatherRainMax\":" + fmtFloatForJson(aiSummary.weatherRainMax, 2) + ",";
  json += "\"weatherScalePct\":" + fmtFloatForJson(aiSummary.weatherScalePct, 1) + ",";
  json += "\"lossWeatherPct\":" + fmtFloatForJson(aiSummary.weatherLossPct, 1) + ",";
  json += "\"lossRainPct\":" + fmtFloatForJson(aiSummary.rainLossPct, 1) + ",";
  json += "\"lossDustPct\":" + fmtFloatForJson(aiSummary.dustLossPct, 1) + ",";
  json += "\"lossHeatPct\":" + fmtFloatForJson(aiSummary.heatLossPct, 1) + ",";
  json += "\"lossTrackingPct\":" + fmtFloatForJson(aiSummary.trackingLossPct, 1) + ",";
  json += "\"flags\":" + String(p.sensorFlags) + ",";
  json += "\"dhtOK\":" + String((p.sensorFlags & SFLAG_DHT_OK) ? 1 : 0) + ",\"inaOK\":" + String((p.sensorFlags & SFLAG_INA_OK) ? 1 : 0) + ",\"tempOK\":" + String((p.sensorFlags & SFLAG_TEMP_OK) ? 1 : 0) + ",\"dsOK\":" + String((p.sensorFlags & SFLAG_TEMP_OK) ? 1 : 0) + ",";
  json += "\"adcExtreme\":" + String((p.sensorFlags & SFLAG_ADC_EXTREME) ? 1 : 0) + ",";
  json += "\"uartLink\":" + String(link ? 1 : 0) + ",\"tx\":" + String(txSensorFrames) + ",\"rx\":" + String(rxAckFrames + rxStatusFrames) + ",\"cmdTx\":" + String(txCmdFrames) + ",";
  json += "\"armed\":" + String(haveActStatus ? latestAct.armed : 0) + ",\"autoMode\":" + String(haveActStatus ? latestAct.autoMode : 0) + ",\"motor\":" + String(haveActStatus ? latestAct.motorDuty : 0) + ",\"servo\":" + String(haveActStatus ? latestAct.servoDeg : 0) + ",";
  json += "\"pump\":" + String(haveActStatus ? latestAct.pumpOn : 0) + ",\"cleaning\":" + String(haveActStatus ? latestAct.cleaningActive : 0) + ",\"cleanAuto\":" + String(haveActStatus ? latestAct.autoCleaning : 0) + ",\"limit\":" + String(haveActStatus ? latestAct.limitActive : 0) + ",\"fault\":" + String(haveActStatus ? latestAct.faultCode : 99);
  json += "}";
  server.send(200, "application/json", json);
}


void handleRetrainCheck() {
  struct RetrainDatasetStatus st = getRetrainDatasetStatus();
  String json = "{";
  json += "\"ready\":" + String(st.enough ? 1 : 0) + ",";
  json += "\"rows\":" + String(st.rows) + ",";
  json += "\"syncedRows\":" + String(st.syncedRows) + ",";
  json += "\"uniqueDates\":" + String(st.uniqueDates) + ",";
  json += "\"firstDate\":\"" + jsonEscape(st.firstDate) + "\",";
  json += "\"lastDate\":\"" + jsonEscape(st.lastDate) + "\",";
  json += "\"timeReady\":" + String(st.timeReady ? 1 : 0) + ",";
  json += "\"minRows\":" + String(RETRAIN_MIN_ROWS) + ",";
  json += "\"recommendedRows\":" + String(RETRAIN_RECOMMENDED_ROWS) + ",";
  json += "\"message\":\"" + jsonEscape(st.message) + "\"";
  json += "}";
  server.send(200, "application/json", json);
}

void handleTimeSync() {
  requestNtpSync();
  delay(300);
  struct TimeFields tf = getTimeFields();
  String json = "{";
  json += "\"timeSynced\":" + String(tf.synced ? 1 : 0) + ",";
  json += "\"timestamp\":\"" + jsonEscape(tf.iso) + "\",";
  json += "\"sta_ip\":\"" + staIP + "\"";
  json += "}";
  server.send(200, "application/json", json);
}

void handleCmd() {
  String c = server.arg("c");
  int16_t v = server.arg("v").toInt();
  uint16_t ms = server.arg("ms").toInt();
  c.toLowerCase();
  if (c == "arm") sendCommand(CMD_ARM);
  else if (c == "disarm") sendCommand(CMD_DISARM);
  else if (c == "auto") sendCommand(CMD_AUTO);
  else if (c == "manual") sendCommand(CMD_MANUAL);
  else if (c == "stop") sendCommand(CMD_STOP);
  else if (c == "alloff") sendCommand(CMD_ALL_OFF);
  else if (c == "motor") sendCommand(CMD_MOTOR, v, ms ? ms : 500);
  else if (c == "servo") sendCommand(CMD_SERVO, v, 0);
  else if (c == "center") sendCommand(CMD_CENTER);
  else if (c == "pump") sendCommand(CMD_PUMP, v, ms ? ms : 0);
  else if (c == "clean") sendCommand(CMD_CLEAN, 1, ms ? ms : 8000);
  else if (c == "cleanauto") sendCommand(CMD_CLEAN_AUTO, v, 0);
  else { server.send(400, "text/plain", "bad command"); return; }
  server.send(200, "text/plain", "OK");
}

void handleDownload() {
  ensureLogHeader();
  File f = LittleFS.open(LOG_PATH, "r");
  if (!f) { server.send(404, "text/plain", "No log"); return; }
  server.streamFile(f, "text/csv");
  f.close();
}

void handleClearLog() {
  LittleFS.remove(LOG_PATH);
  ensureLogHeader();
  server.send(200, "text/plain", "CSV cleared");
}

void handleWifiPage() {
  if (server.method() == HTTP_POST) {
    String ssid = server.arg("ssid");
    String pass = server.arg("pass");
    prefs.begin("wifi", false);
    prefs.putString("ssid", ssid);
    prefs.putString("pass", pass);
    prefs.end();
    server.send(200, "text/html", "<h2>Saved. Restart ESP32.</h2><a href='/'>Back</a>");
    return;
  }
  String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{font-family:Arial;background:#0f172a;color:#e5e7eb;padding:22px}input,button{width:100%;padding:13px;margin:7px 0;border-radius:10px;border:0}.card{background:#111827;padding:18px;border-radius:18px;max-width:520px}.muted{color:#94a3b8;font-size:13px}a{color:#93c5fd}</style></head><body><div class='card'><h2>WiFi Setup</h2><p class='muted'>Set the router WiFi used by the ESP32 for NTP time, weather forecast, and dashboard access.</p><form method='POST'><input name='ssid' value='elnahas' placeholder='Router WiFi name'><input name='pass' placeholder='Password' type='password'><button>Save WiFi</button></form><a href='/'>Back to Dashboard</a></div></body></html>";
  server.send(200, "text/html", html);
}

void handleRoot() {
  String html = R"UIHTML(
<!doctype html>
<html lang="en" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SolarTrack AI | Commercial Dashboard</title>
<style>
:root{--bg:#07111f;--panel:#0f172a;--card:#111c2e;--line:rgba(148,163,184,.18);--muted:#97a6bb;--text:#f8fafc;--blue:#38bdf8;--green:#22c55e;--amber:#f59e0b;--red:#ef4444;--violet:#a78bfa}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top left,#10395f 0,#07111f 38%,#030712 100%);color:var(--text);font-family:Inter,system-ui,-apple-system,Segoe UI,Arial,sans-serif}.top{position:sticky;top:0;z-index:10;background:rgba(7,17,31,.88);backdrop-filter:blur(16px);border-bottom:1px solid var(--line)}.topin{max-width:1380px;margin:auto;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}.brand{display:flex;align-items:center;gap:12px}.logo{width:48px;height:48px;border-radius:16px;background:linear-gradient(135deg,#f59e0b,#38bdf8);display:grid;place-items:center;font-size:24px;box-shadow:0 18px 50px rgba(56,189,248,.18)}h1{font-size:20px;margin:0}.sub{font-size:12px;color:var(--muted);margin-top:3px}.nav{display:flex;gap:8px;flex-wrap:wrap}.nav button,.nav a{border:1px solid var(--line);background:rgba(15,23,42,.84);color:var(--text);padding:10px 13px;border-radius:12px;text-decoration:none;cursor:pointer;font-weight:800}.nav button.active{border-color:rgba(56,189,248,.65);box-shadow:0 0 0 3px rgba(56,189,248,.11)}.wrap{max-width:1380px;margin:auto;padding:18px}.page{display:none}.page.active{display:block}.hero{border:1px solid var(--line);border-radius:26px;background:linear-gradient(135deg,rgba(56,189,248,.12),rgba(34,197,94,.07)),rgba(15,23,42,.78);padding:18px;margin-bottom:16px;box-shadow:0 25px 80px rgba(0,0,0,.25)}.hero h2{margin:0 0 6px;font-size:24px}.hero p{margin:0;color:var(--muted);line-height:1.55}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:14px}.card{grid-column:span 3;background:rgba(17,28,46,.9);border:1px solid var(--line);border-radius:22px;padding:16px;box-shadow:0 15px 44px rgba(0,0,0,.23);overflow:hidden}.span2{grid-column:span 2}.span3{grid-column:span 3}.span4{grid-column:span 4}.span5{grid-column:span 5}.span6{grid-column:span 6}.span7{grid-column:span 7}.span8{grid-column:span 8}.span12{grid-column:span 12}.label{font-size:12px;color:var(--muted);letter-spacing:.25px;text-transform:uppercase}.val{font-size:31px;font-weight:950;margin-top:8px}.unit{font-size:13px;color:var(--muted);margin-left:5px}.muted{color:var(--muted)}.mono{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.pill{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:900;white-space:nowrap}.ok{background:rgba(34,197,94,.12);color:#86efac;border:1px solid rgba(34,197,94,.32)}.warn{background:rgba(245,158,11,.12);color:#fcd34d;border:1px solid rgba(245,158,11,.32)}.bad{background:rgba(239,68,68,.12);color:#fca5a5;border:1px solid rgba(239,68,68,.32)}.bar{height:8px;border-radius:999px;background:rgba(148,163,184,.14);overflow:hidden;margin-top:11px}.bar i{display:block;width:0;height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--blue),var(--green))}.kv{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid var(--line);align-items:center}.kv:last-child{border-bottom:0}.section{display:flex;justify-content:space-between;align-items:end;gap:12px;flex-wrap:wrap;margin:24px 2px 12px}.section h2{margin:0;font-size:19px}.section p{margin:3px 0 0;color:var(--muted);font-size:13px}.controls{display:grid;grid-template-columns:repeat(4,1fr);gap:9px}.btn{border:0;border-radius:14px;padding:12px 10px;background:linear-gradient(135deg,#2563eb,#38bdf8);color:#fff;font-weight:950;text-align:center;text-decoration:none;cursor:pointer}.btn.danger{background:linear-gradient(135deg,#dc2626,#f97316)}.btn.gray{background:linear-gradient(135deg,#334155,#64748b)}.btn.green{background:linear-gradient(135deg,#16a34a,#22c55e)}.btn:disabled{opacity:.45;cursor:not-allowed}canvas{width:100%;height:230px;border-radius:18px;background:rgba(2,6,23,.34);border:1px solid var(--line)}.case{position:relative}.case:before{content:"";position:absolute;right:-50px;bottom:-70px;width:170px;height:170px;border-radius:50%;background:rgba(56,189,248,.08)}.case.best:before{background:rgba(34,197,94,.1)}.case.worst:before{background:rgba(239,68,68,.1)}.reason{font-size:22px;font-weight:950;line-height:1.35;margin-top:8px}.table{width:100%;border-collapse:collapse;font-size:13px}.table th,.table td{padding:10px;border-bottom:1px solid var(--line);text-align:left}.table th{color:var(--muted);font-weight:900}.input{width:100%;background:#0b1220;border:1px solid var(--line);color:var(--text);padding:12px;border-radius:12px;margin-top:8px}.small{font-size:12px}.split{display:grid;grid-template-columns:1fr 1fr;gap:12px}.footerNote{font-size:12px;color:var(--muted);line-height:1.6;margin-top:12px}@media(max-width:1050px){.card,.span2,.span3,.span4,.span5,.span6,.span7,.span8,.span12{grid-column:span 12}.controls{grid-template-columns:repeat(2,1fr)}.split{grid-template-columns:1fr}.val{font-size:27px}}
</style>
</head>
<body>
<div class="top"><div class="topin"><div class="brand"><div class="logo">☀️</div><div><h1>SolarTrack AI Commercial</h1><div class="sub">Live control, production analytics, weather-aware forecast, and retraining workflow</div></div></div><div class="nav"><button id="tabLive" class="active" onclick="showPage('live')">Live Sensors & Control</button><button id="tabForecast" onclick="showPage('forecast')">AI Forecast & Analytics</button><a href="/download">CSV</a><a href="/wifi">WiFi</a></div></div></div>
<div class="wrap">
<section id="pageLive" class="page active">
  <div class="hero"><h2>Live plant overview</h2><p>Real-time sensors, electrical readings, actuator link, and tracking/cleaning control.</p></div>
  <div class="grid">
    <div class="card span3"><div class="label">Local time</div><div class="val mono" style="font-size:18px" id="timestamp">--</div><div style="margin-top:8px"><span id="timeSync" class="pill warn">Checking time</span></div></div>
    <div class="card span3"><div class="label">Actuator link</div><div style="margin-top:10px"><span id="linkBig" class="pill bad">--</span></div><div style="margin-top:8px"><span id="modeBig" class="pill warn">--</span></div></div>
    <div class="card span3"><div class="label">Network</div><div class="val mono" style="font-size:19px" id="sta">--</div><div class="muted small">Refresh <span id="lastRefresh">--</span></div></div>
    <div class="card span3"><div class="label">System</div><div class="val" style="font-size:19px" id="faultText">--</div><div class="muted small">Seq <span id="seq">--</span> • Uptime <span id="uptime">--</span>s</div></div>
    <div class="card"><div class="label">Solar power</div><div class="val"><span id="pwr">--</span><span class="unit">W</span></div><div class="bar"><i id="pwrBar"></i></div></div>
    <div class="card"><div class="label">Irradiance</div><div class="val"><span id="irr">--</span><span class="unit">W/m²</span></div><div class="bar"><i id="irrBar"></i></div></div>
    <div class="card"><div class="label">Panel temperature</div><div class="val"><span id="panel">--</span><span class="unit">°C</span></div></div>
    <div class="card"><div class="label">Ambient</div><div class="val"><span id="air">--</span><span class="unit">°C</span></div><div class="muted">Humidity <span id="rh">--</span>%</div></div>
    <div class="card span4"><div class="label">Electrical</div><div class="kv"><span>Bus voltage</span><b><span id="vbus">--</span> V</b></div><div class="kv"><span>Current</span><b><span id="cur">--</span> A</b></div><div class="kv"><span>INA226</span><b id="inaState">--</b></div><div class="kv"><span>DHT22</span><b id="dhtStatus">--</b></div></div>
    <div class="card span4"><div class="label">Tracking light sensors</div><div class="kv"><span>Light average</span><b><span id="lightAvg">--</span> / <span id="lightPct">--</span></b></div><div class="bar"><i id="lightBar"></i></div><div class="kv"><span>TL/TR/BL/BR</span><b class="mono"><span id="tl">--</span>/<span id="tr">--</span>/<span id="bl">--</span>/<span id="br">--</span></b></div><div class="kv"><span>Error H/V</span><b class="mono"><span id="errH">--</span>/<span id="errV">--</span></b></div></div>
    <div class="card span4"><div class="label">Environment & safety</div><div class="kv"><span>Rain</span><b id="rainWet">--</b></div><div class="kv"><span>Rain analog</span><b><span id="rainAO">--</span> / <span id="rainPct">--</span>%</b></div><div class="bar"><i id="rainBar"></i></div><div class="kv"><span>Dust</span><b><span id="dustUg">--</span> µg/m³</b></div><div class="kv"><span>PIR1 / PIR2 / Tilt</span><b><span id="pir1">--</span> <span id="pir2">--</span> <span id="tilt">--</span></b></div></div>
  </div>
  <div class="section"><div><h2>Tracking and cleaning control</h2><p>Manual commands are sent to the actuator hub using the existing UART protocol.</p></div></div>
  <div class="grid"><div class="card span7"><div class="controls"><button class="btn green" onclick="cmd('arm')">ARM</button><button class="btn danger" onclick="cmd('disarm')">DISARM</button><button class="btn" onclick="cmd('auto')">AUTO</button><button class="btn gray" onclick="cmd('manual')">MANUAL</button><button class="btn danger" onclick="cmd('stop')">STOP</button><button class="btn danger" onclick="cmd('alloff')">ALL OFF</button><button class="btn" onclick="cmd('center')">CENTER</button><button class="btn" onclick="cmd('clean')">CLEAN</button><button class="btn" onclick="cmd('pump',1)">PUMP ON</button><button class="btn gray" onclick="cmd('pump',0)">PUMP OFF</button><button class="btn" onclick="cmd('motor',160,700)">MOTOR +</button><button class="btn" onclick="cmd('motor',-160,700)">MOTOR -</button><button class="btn" onclick="cmd('servo',90)">SERVO 90</button><button class="btn gray" onclick="syncTime()">SYNC TIME</button><a class="btn" href="/download">Download CSV</a><a class="btn danger" href="/clearlog">Clear CSV</a></div></div><div class="card span5"><div class="label">Actuator state</div><div class="kv"><span>Motor duty</span><b id="motor">--</b></div><div class="kv"><span>Servo</span><b><span id="servo">--</span>°</b></div><div class="kv"><span>Pump</span><b id="pump">--</b></div><div class="kv"><span>Cleaning</span><b id="clean">--</b></div></div></div>
  <div class="section"><div><h2>Live charts</h2><p>Realtime sensor and production history kept in the browser.</p></div></div>
  <div class="grid"><div class="card span6"><div class="label">Power vs AI now</div><canvas id="chartPower"></canvas></div><div class="card span6"><div class="label">Irradiance and panel temperature</div><canvas id="chartIrrTemp"></canvas></div><div class="card span6"><div class="label">Ambient temperature and humidity</div><canvas id="chartEnv"></canvas></div><div class="card span6"><div class="label">Rain and dust</div><canvas id="chartRainDust"></canvas></div></div>
</section>
<section id="pageForecast" class="page">
  <div class="hero"><h2>Forecast and production intelligence</h2><p>Best, normal, and worst-case forecast for tomorrow, plus production comparison, loss factors, weather influence, and retraining readiness.</p></div>
  <div class="grid">
    <div class="card span4 case best"><div class="label">Tomorrow best case</div><div class="val"><span id="fcBest">--</span><span class="unit">Wh</span></div><div class="muted"><span id="fcBestKwh">--</span> kWh</div><div class="bar"><i id="fcBestBar"></i></div></div>
    <div class="card span4 case"><div class="label">Tomorrow normal case</div><div class="val"><span id="fcNormal">--</span><span class="unit">Wh</span></div><div class="muted"><span id="fcNormalKwh">--</span> kWh</div><div class="bar"><i id="fcNormalBar"></i></div></div>
    <div class="card span4 case worst"><div class="label">Tomorrow worst case</div><div class="val"><span id="fcWorst">--</span><span class="unit">Wh</span></div><div class="muted"><span id="fcWorstKwh">--</span> kWh</div><div class="bar"><i id="fcWorstBar"></i></div></div>
    <div class="card span3"><div class="label">Next hour</div><div class="val"><span id="nextHour">--</span><span class="unit">Wh</span></div><div class="muted">AI instantaneous <span id="aiNow">--</span> W</div></div>
    <div class="card span3"><div class="label">Yesterday actual</div><div class="val"><span id="yWh">--</span><span class="unit">Wh</span></div><div class="muted"><span id="yDate">--</span> • <span id="ySource">--</span> • samples <span id="ySamples">--</span></div></div>
    <div class="card span3"><div class="label">Today so far</div><div class="val"><span id="todayWh">--</span><span class="unit">Wh</span></div><div class="muted">samples <span id="todaySamples">--</span></div></div>
    <div class="card span3"><div class="label">Forecast confidence</div><div class="val"><span id="aiConf">--</span><span class="unit">%</span></div><div class="bar"><i id="aiConfBar"></i></div><div class="muted">Uncertainty ±<span id="uncertainty">--</span>%</div></div>
    <div class="card span4"><div class="label">Gain / loss vs normal baseline</div><div class="val"><span id="gainPct">--</span><span class="unit">%</span></div><div class="muted"><span id="gainWh">--</span> Wh vs baseline</div></div>
    <div class="card span4"><div class="label">Change vs yesterday</div><div class="val"><span id="vsYesterday">--</span><span class="unit">%</span></div><div class="muted">Normal forecast compared with yesterday actual</div></div>
    <div class="card span4"><div class="label">Main impact factor</div><div class="reason" id="primaryFactor">--</div></div>
    <div class="card span6"><div class="label">Why this forecast?</div><div class="reason" style="font-size:18px" id="factorSummary">--</div></div>
    <div class="card span6"><div class="label">Recommended action</div><div class="reason" style="font-size:18px" id="recommendation">--</div></div>
    <div class="card span4"><div class="label">Weather status</div><div style="margin-top:8px" id="weatherPill">--</div><div class="kv"><span>Location</span><b><span id="wLat">--</span>, <span id="wLon">--</span></b></div><div class="kv"><span>Avg radiation</span><b><span id="wIrr">--</span> W/m²</b></div><div class="kv"><span>Weather scale</span><b><span id="wScale">--</span>%</b></div></div>
    <div class="card span4"><div class="label">Weather details</div><div class="kv"><span>Cloud cover</span><b><span id="wCloud">--</span>%</b></div><div class="kv"><span>Rain probability</span><b><span id="wRain">--</span>%</b></div><div class="kv"><span>Temp / humidity</span><b><span id="wTemp">--</span>°C / <span id="wHum">--</span>%</b></div></div>
    <div class="card span4"><div class="label">Model</div><div class="kv"><span>Name</span><b class="mono" id="aiModel">--</b></div><div class="kv"><span>CSV rows</span><b id="retRows">--</b></div><div class="kv"><span>CSV dates</span><b id="retDates">--</b></div><div class="kv"><span>Training ready</span><b id="retReady">--</b></div></div>
  </div>
  <div class="section"><div><h2>Forecast charts</h2><p>Cases, trend, production comparison, and loss breakdown.</p></div></div>
  <div class="grid"><div class="card span6"><div class="label">Tomorrow cases</div><canvas id="chartCases"></canvas></div><div class="card span6"><div class="label">Forecast trend</div><canvas id="chartForecastTrend"></canvas></div><div class="card span6"><div class="label">Yesterday vs tomorrow</div><canvas id="chartActual"></canvas></div><div class="card span6"><div class="label">Loss contributors</div><canvas id="chartLoss"></canvas></div></div>
  <div class="section"><div><h2>AI retraining workflow</h2><p>The ESP32 validates the CSV. Python retraining runs on your laptop/Raspberry Pi and generates a new model header.</p></div></div>
  <div class="grid"><div class="card span6"><div class="label">Dataset readiness</div><div class="kv"><span>Rows / recommended</span><b><span id="rRows">--</span> / <span id="rRec">--</span></b></div><div class="kv"><span>Synced rows</span><b id="rSynced">--</b></div><div class="kv"><span>Date range</span><b><span id="rFirst">--</span> → <span id="rLast">--</span></b></div><div class="kv"><span>Status</span><b id="rStatus">--</b></div><button class="btn green" style="width:100%;margin-top:12px" onclick="checkRetrain()">Check Dataset</button></div><div class="card span6"><div class="label">Python retraining server</div><input class="input mono" id="trainerUrl" value="http://127.0.0.1:5055" placeholder="Trainer server URL"><div class="split" style="margin-top:10px"><button class="btn" onclick="runRetrain()">Run Retraining</button><a class="btn gray" href="/download">Download CSV</a></div><div id="trainerResult" class="footerNote">Run retraining_server.py on the computer first. The button will call the server only when the ESP32 CSV is ready.</div></div></div>
</section>
</div>
<script>
const q=id=>document.getElementById(id),MAX=90,hist={power:[],irr:[],panel:[],air:[],rh:[],rain:[],dust:[],aiNow:[],norm:[],best:[],worst:[],yest:[]};let latestData=null;
function showPage(p){q('pageLive').classList.toggle('active',p==='live');q('pageForecast').classList.toggle('active',p==='forecast');q('tabLive').classList.toggle('active',p==='live');q('tabForecast').classList.toggle('active',p==='forecast');setTimeout(redraw,80)}
function fmt(v,d=1){v=Number(v);return Number.isFinite(v)?v.toFixed(d):'--'}function push(k,v){v=Number(v);if(Number.isFinite(v)){hist[k].push(v);if(hist[k].length>MAX)hist[k].shift()}}
function pill(ok,good='OK',bad='Missing'){return `<span class="pill ${ok?'ok':'bad'}">${ok?good:bad}</span>`}function warnPill(t){return `<span class="pill warn">${t}</span>`}function onoff(v){return v?warnPill('ON'):pill(true,'OFF','')}function setBar(id,val,max){let e=q(id);if(e)e.style.width=Math.max(0,Math.min(100,(Number(val)||0)/max*100))+'%'}
async function cmd(c,v=0,ms=0){try{await fetch(`/cmd?c=${encodeURIComponent(c)}&v=${v}&ms=${ms}`)}catch(e){alert('Command failed')}}async function syncTime(){try{let r=await (await fetch('/time-sync')).json();alert(r.timeSynced?'Time synced: '+r.timestamp:'Time is not synced. Check router WiFi/internet.')}catch(e){alert('Time sync request failed')}}
function draw(id,series){let c=q(id);if(!c)return;let r=c.getBoundingClientRect(),dpr=devicePixelRatio||1;c.width=Math.max(10,r.width*dpr);c.height=Math.max(10,r.height*dpr);let ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);let w=r.width,h=r.height,p=24;ctx.clearRect(0,0,w,h);ctx.strokeStyle='rgba(148,163,184,.18)';ctx.lineWidth=1;for(let i=0;i<4;i++){let y=p+(h-2*p)*i/3;ctx.beginPath();ctx.moveTo(p,y);ctx.lineTo(w-p,y);ctx.stroke()}let vals=[];series.forEach(s=>vals=vals.concat(s.data.filter(Number.isFinite)));if(vals.length<2)return;let mn=Math.min(...vals),mx=Math.max(...vals);if(mx===mn){mx+=1;mn-=1}let pad=(mx-mn)*.12;mn-=pad;mx+=pad;series.forEach(s=>{if(s.data.length<2)return;ctx.strokeStyle=s.color;ctx.lineWidth=2.4;ctx.beginPath();s.data.forEach((v,i)=>{v=Number(v);if(!Number.isFinite(v))return;let x=p+(w-2*p)*i/(MAX-1),y=h-p-(h-2*p)*(v-mn)/(mx-mn);i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke()});ctx.fillStyle='rgba(226,232,240,.62)';ctx.font='11px system-ui';ctx.fillText(mx.toFixed(1),3,14);ctx.fillText(mn.toFixed(1),3,h-6)}
function drawBars(id,items){let c=q(id);if(!c)return;let r=c.getBoundingClientRect(),dpr=devicePixelRatio||1;c.width=Math.max(10,r.width*dpr);c.height=Math.max(10,r.height*dpr);let ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);let w=r.width,h=r.height,p=30;ctx.clearRect(0,0,w,h);let max=Math.max(1,...items.map(x=>Number(x.v)||0));let bw=(w-2*p)/items.length*.55;items.forEach((it,i)=>{let v=Number(it.v)||0,x=p+(w-2*p)*(i+.5)/items.length-bw/2,bh=(h-2*p)*v/max,y=h-p-bh;ctx.fillStyle=it.c;ctx.fillRect(x,y,bw,bh);ctx.fillStyle='rgba(245,248,255,.92)';ctx.font='12px system-ui';ctx.textAlign='center';ctx.fillText(it.t,x+bw/2,h-8);ctx.fillText(v.toFixed(1),x+bw/2,Math.max(14,y-6))})}
function redraw(){draw('chartPower',[{data:hist.power,color:'#38bdf8'},{data:hist.aiNow,color:'#f59e0b'}]);draw('chartIrrTemp',[{data:hist.irr,color:'#38bdf8'},{data:hist.panel,color:'#f59e0b'}]);draw('chartEnv',[{data:hist.air,color:'#22c55e'},{data:hist.rh,color:'#a78bfa'}]);draw('chartRainDust',[{data:hist.rain,color:'#38bdf8'},{data:hist.dust,color:'#f59e0b'}]);draw('chartForecastTrend',[{data:hist.norm,color:'#38bdf8'},{data:hist.best,color:'#22c55e'},{data:hist.worst,color:'#ef4444'}]);draw('chartActual',[{data:hist.yest,color:'#a78bfa'},{data:hist.norm,color:'#38bdf8'}])}
async function checkRetrain(){try{let r=await (await fetch('/api/retrain-check')).json();q('rRows').textContent=r.rows;q('rRec').textContent=r.recommendedRows;q('rSynced').textContent=r.syncedRows;q('rFirst').textContent=r.firstDate;q('rLast').textContent=r.lastDate;q('rStatus').innerHTML=r.ready?pill(true,'Ready',''):warnPill(r.message);q('trainerResult').textContent=r.message;return r}catch(e){q('trainerResult').textContent='Dataset check failed';return null}}
async function runRetrain(){let r=await checkRetrain();if(!r||!r.ready){q('trainerResult').textContent='Retraining blocked: '+(r?r.message:'dataset check failed');return}let url=q('trainerUrl').value.trim().replace(/\/$/,'');q('trainerResult').textContent='Calling trainer server...';try{let out=await (await fetch(`${url}/retrain?esp=${encodeURIComponent(location.origin)}`)).json();q('trainerResult').textContent=out.ok?`Retrained: ${out.model_name} • rows ${out.dataset_rows_valid}`:`Trainer error: ${out.error||out.message}`;}catch(e){q('trainerResult').textContent='Trainer server not reachable. Start retraining_server.py on the computer first.'}}
async function update(){try{let d=await (await fetch('/api')).json();latestData=d;q('lastRefresh').textContent=new Date().toLocaleTimeString();q('timestamp').textContent=d.timestamp||'--';q('timeSync').innerHTML=d.timeSynced?pill(true,'NTP Synced',''):warnPill('NTP Not Synced');q('linkBig').innerHTML=d.uartLink?pill(true,'UART Connected',''):pill(false,'','UART Offline');q('modeBig').innerHTML=`<span class="pill ${d.armed?'ok':'bad'}">${d.armed?'ARMED':'DISARMED'} • ${d.autoMode?'AUTO':'MANUAL'}</span>`;q('sta').textContent=d.sta_ip||'Not connected';q('seq').textContent=d.seq;q('uptime').textContent=d.uptime;q('faultText').textContent='Fault code '+d.fault;
q('pwr').textContent=fmt(d.powerW,2);q('irr').textContent=fmt(d.irradiance,1);q('panel').textContent=fmt(d.panel,2);q('air').textContent=d.air;q('rh').textContent=d.rh;q('dhtStatus').innerHTML=pill(d.dhtOK,'DHT22 OK','DHT22 Missing');setBar('pwrBar',d.powerW,30);setBar('irrBar',d.irradiance||0,1000);q('vbus').textContent=fmt(d.busV,2);q('cur').textContent=fmt(d.currentA,3);q('inaState').innerHTML=pill(d.inaOK,'OK','Missing');q('lightAvg').textContent=fmt(d.lightAvg,1);q('lightPct').textContent=fmt(d.lightPct,1)+'%';q('tl').textContent=d.tl;q('tr').textContent=d.tr;q('bl').textContent=d.bl;q('br').textContent=d.br;q('errH').textContent=d.errH;q('errV').textContent=d.errV;setBar('lightBar',d.lightPct,100);q('rainAO').textContent=d.rainAO;q('rainPct').textContent=d.rainPct;q('rainWet').innerHTML=d.rainWet?warnPill('WET'):pill(true,'DRY','');setBar('rainBar',d.rainPct,100);q('pir1').innerHTML=onoff(d.pir1);q('pir2').innerHTML=onoff(d.pir2);q('tilt').innerHTML=d.tilt?warnPill('ACTIVE'):pill(true,'NORMAL','');q('dustUg').textContent=fmt(d.dustUg,1);q('motor').textContent=d.motor;q('servo').textContent=d.servo;q('pump').innerHTML=onoff(d.pump);q('clean').innerHTML=onoff(d.cleaning);
q('aiModel').textContent=d.aiModel||'AI model';q('aiConf').textContent=fmt(d.aiConfidence,1);q('uncertainty').textContent=fmt(d.aiUncertaintyPct,1);setBar('aiConfBar',d.aiConfidence||0,100);q('fcBest').textContent=fmt(d.aiTomorrowBestWh,1);q('fcBestKwh').textContent=fmt(d.aiTomorrowBestKWh,4);q('fcNormal').textContent=fmt(d.aiTomorrowNormalWh,1);q('fcNormalKwh').textContent=fmt(d.aiTomorrowNormalKWh,4);q('fcWorst').textContent=fmt(d.aiTomorrowWorstWh,1);q('fcWorstKwh').textContent=fmt(d.aiTomorrowWorstKWh,4);setBar('fcBestBar',d.aiTomorrowBestWh,320);setBar('fcNormalBar',d.aiTomorrowNormalWh,320);setBar('fcWorstBar',d.aiTomorrowWorstWh,320);q('nextHour').textContent=fmt(d.aiNextHourWh,2);q('aiNow').textContent=fmt(d.aiNowPowerW,2);q('yWh').textContent=fmt(d.actualYesterdayWh,1);q('yDate').textContent=d.actualYesterdayDate||'NA';q('ySource').textContent=(d.actualYesterdaySource==='csv')?'CSV actual':'Excel seed';q('ySamples').textContent=d.actualYesterdaySamples;q('todayWh').textContent=fmt(d.actualTodayWh,1);q('todaySamples').textContent=d.actualTodaySamples;q('gainPct').textContent=fmt(d.aiGainLossPct,1);q('gainWh').textContent=fmt(d.aiGainLossWh,1);q('vsYesterday').textContent=fmt(d.aiVsYesterdayPct,1);q('primaryFactor').textContent=d.aiPrimaryFactor||'--';q('factorSummary').textContent=d.aiFactorSummary||'--';q('recommendation').textContent=d.aiRecommendation||'--';
q('weatherPill').innerHTML=d.weatherUsed?pill(true,'Weather online',''):warnPill(d.weatherStatus||'Internal profile');q('wLat').textContent=fmt(d.weatherLat,4);q('wLon').textContent=fmt(d.weatherLon,4);q('wIrr').textContent=fmt(d.weatherIrrAvg,1);q('wScale').textContent=fmt(d.weatherScalePct,1);q('wCloud').textContent=fmt(d.weatherCloudAvg,1);q('wRain').textContent=fmt(d.weatherRainMax,1);q('wTemp').textContent=fmt(d.weatherTempAvg,1);q('wHum').textContent=fmt(d.weatherHumidityAvg,1);q('retRows').textContent=d.retrainRows;q('retDates').textContent=d.retrainFirstDate+' → '+d.retrainLastDate;q('retReady').innerHTML=d.retrainReady?pill(true,'Ready',''):warnPill('Collecting');q('rRows').textContent=d.retrainRows;q('rRec').textContent=d.retrainRecommendedRows;q('rSynced').textContent=d.retrainSyncedRows;q('rFirst').textContent=d.retrainFirstDate;q('rLast').textContent=d.retrainLastDate;q('rStatus').innerHTML=d.retrainReady?pill(true,'Ready',''):warnPill(d.retrainMessage||'Collecting');
push('power',d.powerW);push('irr',d.irradiance);push('panel',d.panel);push('air',d.airNum);push('rh',d.rhNum);push('rain',d.rainPct);push('dust',d.dustUg);push('aiNow',d.aiNowPowerW);push('norm',d.aiTomorrowNormalWh);push('best',d.aiTomorrowBestWh);push('worst',d.aiTomorrowWorstWh);push('yest',d.actualYesterdayWh);drawBars('chartCases',[{t:'Worst',v:d.aiTomorrowWorstWh,c:'#ef4444'},{t:'Normal',v:d.aiTomorrowNormalWh,c:'#38bdf8'},{t:'Best',v:d.aiTomorrowBestWh,c:'#22c55e'}]);drawBars('chartLoss',[{t:'Weather',v:d.lossWeatherPct,c:'#38bdf8'},{t:'Rain',v:d.lossRainPct,c:'#60a5fa'},{t:'Dust',v:d.lossDustPct,c:'#f59e0b'},{t:'Heat',v:d.lossHeatPct,c:'#ef4444'},{t:'Track',v:d.lossTrackingPct,c:'#a78bfa'}]);redraw()}catch(e){q('lastRefresh').innerHTML='<span class="pill bad">Connection lost</span>';console.log(e)}}
setInterval(update,1100);addEventListener('resize',redraw);update();
</script>
</body>
</html>
)UIHTML";
  server.send(200, "text/html", html);
}


void startWiFi() {
  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false);
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print(F("AP started: ")); Serial.print(AP_SSID); Serial.print(F(" IP=")); Serial.println(WiFi.softAPIP());

  prefs.begin("wifi", true);
  String ssid = prefs.getString("ssid", "");
  String pass = prefs.getString("pass", "");
  prefs.end();

  // If no WiFi was saved from /wifi yet, use the project owner router credentials.
  if (!ssid.length()) {
    ssid = DEFAULT_STA_SSID;
    pass = DEFAULT_STA_PASS;
  }

  if (ssid.length()) {
    Serial.print(F("Connecting to router WiFi: ")); Serial.println(ssid);
    WiFi.begin(ssid.c_str(), pass.c_str());
    uint32_t start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 9000) delay(100);
    if (WiFi.status() == WL_CONNECTED) {
      staOK = true;
      staIP = WiFi.localIP().toString();
      configTzTime(TZ_INFO, "pool.ntp.org", "time.nist.gov");
      Serial.print(F("STA connected IP=")); Serial.println(staIP);
    } else {
      Serial.println(F("Router WiFi not connected. Backup AP is still active."));
    }
  }
}

void startWeb() {
  server.on("/", handleRoot);
  server.on("/api", handleApi);
  server.on("/api/retrain-check", handleRetrainCheck);
  server.on("/time-sync", handleTimeSync);
  server.on("/cmd", handleCmd);
  server.on("/download", handleDownload);
  server.on("/clearlog", handleClearLog);
  server.on("/wifi", handleWifiPage);
  server.begin();
}

// ---------------- Serial commands from working test, plus web command shortcuts ----------------
void printHelp() {
  Serial.println(F("\nSensor Hub commands:"));
  Serial.println(F("  help | once | stream on | stream off | rate 500 | scan | calib_ina | link"));
  Serial.println(F("  arm | disarm | auto | manual | stop | motor 160 | motor -160 | servo 90 | pump on | pump off | clean"));
  Serial.println(F("Dashboard: connect to router WiFi Mekkawy or backup AP SolarTracker_AP / 12345678, then open http://192.168.4.1 or the shown STA IP"));
  Serial.println(F("DHT22 is on GPIO4, replacing DS18B20. GPIO22 is INA226 SCL only."));
}

void handleSerialCommand() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n');
  cmd.trim();
  String lower = cmd;
  lower.toLowerCase();
  if (lower == "help" || lower == "?") printHelp();
  else if (lower == "scan") i2cScan();
  else if (lower == "stream on") { streamEnabled = true; Serial.println(F("stream enabled")); }
  else if (lower == "stream off") { streamEnabled = false; Serial.println(F("stream disabled")); }
  else if (lower == "calib_ina") { calibrateINA226(); Serial.println(F("INA226 calibration written")); }
  else if (lower == "link") printLinkStats();
  else if (lower.startsWith("rate ")) { samplePeriodMs = constrain(lower.substring(5).toInt(), 100, 5000); Serial.print(F("samplePeriodMs=")); Serial.println(samplePeriodMs); }
  else if (lower == "once") { SensorPayload p = readAllSensors(); latest = p; latestValid = true; printCompactPayload(p); sendFrame(LinkSerial, MSG_SENSOR, (const uint8_t *)&p, sizeof(p)); txSensorFrames++; }
  else if (lower == "arm") sendCommand(CMD_ARM);
  else if (lower == "disarm") sendCommand(CMD_DISARM);
  else if (lower == "auto") sendCommand(CMD_AUTO);
  else if (lower == "manual") sendCommand(CMD_MANUAL);
  else if (lower == "stop") sendCommand(CMD_STOP);
  else if (lower.startsWith("motor ")) sendCommand(CMD_MOTOR, lower.substring(6).toInt(), 700);
  else if (lower.startsWith("servo ")) sendCommand(CMD_SERVO, lower.substring(6).toInt(), 0);
  else if (lower == "center") sendCommand(CMD_CENTER);
  else if (lower == "pump on") sendCommand(CMD_PUMP, 1, 0);
  else if (lower == "pump off") sendCommand(CMD_PUMP, 0, 0);
  else if (lower == "clean") sendCommand(CMD_CLEAN, 1, 8000);
  else if (lower.length()) { Serial.print(F("Unknown command: ")); Serial.println(cmd); printHelp(); }
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println(F("\n=== ESP32 #1 SENSOR HUB — DHT22 GPIO4 + INA226 — V/A DISPLAY ==="));

  pinMode(PIN_RAIN_DO, INPUT);
  pinMode(PIN_PIR_1, INPUT);
  pinMode(PIN_PIR_2, INPUT);
  pinMode(PIN_TILT, INPUT_PULLUP);
  pinMode(PIN_DUST_LED, OUTPUT);
  digitalWrite(PIN_DUST_LED, DUST_LED_ACTIVE_LOW ? HIGH : LOW);

  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);  // safer for 0..3.3 V testing

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, I2C_FREQ_HZ);
  LinkSerial.begin(115200, SERIAL_8N1, PIN_UART_RX2, PIN_UART_TX2);

  dht.begin();
  Serial.print(F("DHT22 DATA on GPIO")); Serial.print(PIN_DHT); Serial.println(F(" / old DS18B20 socket"));
  delay(2200); // give DHT22 time before first valid read
  updateDHTCache(true);

  inaOK = i2cPresent(INA226_ADDR);
  Serial.print(F("INA226 @0x40: ")); Serial.println(inaOK ? F("OK") : F("NOT FOUND"));
  if (inaOK) calibrateINA226();

  // Dashboard / logger additions start after the original working-test sensor setup.
  if (!LittleFS.begin(true)) Serial.println(F("LittleFS mount failed"));
  else ensureLogHeader();

  startWiFi();
  startWeb();
  i2cScan();
  printHelp();
  Serial.println(F("\nSensorHub is running the exact test-code sensor timing with professional dashboard enabled."));
}

void loop() {
  server.handleClient();
  static uint32_t lastNtpRetryMs = 0;
  if (WiFi.status() == WL_CONNECTED && time(nullptr) <= 1700000000 && millis() - lastNtpRetryMs > 60000UL) {
    lastNtpRetryMs = millis();
    requestNtpSync();
  }
  updateWeatherForecastIfNeeded(false);
  handleSerialCommand();
  handleIncomingLink();

  const uint32_t now = millis();
  if (streamEnabled && now - lastSampleMs >= samplePeriodMs) {
    lastSampleMs = now;
    SensorPayload p = readAllSensors();
    latest = p;
    latestValid = true;
    sendFrame(LinkSerial, MSG_SENSOR, (const uint8_t *)&p, sizeof(p));
    txSensorFrames++;

    if (now - lastPrintMs >= 1000) {
      lastPrintMs = now;
      printCompactPayload(p);
      printLinkStats();
    }
    if (lastLogMs == 0 || now - lastLogMs >= LOG_PERIOD_MS) {
      lastLogMs = now;
      appendCsvRow(p);
    }
  }
}
