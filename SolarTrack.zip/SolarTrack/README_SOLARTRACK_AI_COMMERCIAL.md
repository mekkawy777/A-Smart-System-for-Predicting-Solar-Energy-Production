# SolarTrack AI Commercial Dashboard Package

## Upload order
1. Open `SensorHub_AI_Forecast_Professional_Dashboard/SensorHub_AI_Forecast_Professional_Dashboard.ino` in Arduino IDE.
2. Select your ESP32 board and upload.
3. Upload the actuator sketch from `ActuatorHub_FinalDelivery_ProDashboard_EN_AI_READY/` to the second ESP32.
4. Open Serial Monitor at `115200` and use the STA IP shown there.

## Dashboard pages
- **Live Sensors & Control**: realtime sensor cards, electrical values, UART actuator status, tracking and cleaning controls, live charts.
- **AI Forecast & Analytics**: tomorrow best/normal/worst production, next-hour energy, yesterday actual production, today-so-far production, gain/loss percentage, weather impact, loss breakdown, and model retraining workflow.

## Time sync
The dashboard shows `NTP Synced` when the ESP32 gets real time through router WiFi. CSV rows logged without NTP time are not accepted for retraining.
Use the `SYNC TIME` button after WiFi is connected.

## Excel seed fallback
Until the ESP32 CSV contains real logged data, `Yesterday actual` falls back to the last day in the Excel training set:
- Date: `2026-06-12`
- Production: `81.4125 Wh`
- Samples: `96`

Once real CSV data exists for yesterday, the dashboard automatically switches to `CSV actual`.

## Retraining button
The ESP32 cannot run Python locally. The dashboard button checks the ESP32 CSV and then calls a local Python retraining server running on your laptop/Raspberry Pi.

Run this on the computer before pressing `Run Retraining`:

```bash
python retraining_server.py --base-excel training_data.xlsx --outdir ai_auto_output
```

The dashboard calls `http://127.0.0.1:5055` by default. Retraining is blocked until the CSV has at least:
- 288 valid rows
- 3 different dates
- mostly NTP-synced timestamps

The server generates:
- `ai_auto_output/SolarAI_Model.generated.h`
- `ai_auto_output/ai_model_metrics.json`
- `ai_auto_output/auto_training_dataset.csv`

After generating a new model header, copy the arrays into the model block in the SensorHub sketch and upload again.
