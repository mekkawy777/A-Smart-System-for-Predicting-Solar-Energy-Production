/*
  Dual ESP32 Solar Tracker - ACTUATOR HUB
  TEST-CODE-BASE FAST UART VERSION

  This actuator code is based on your working standalone actuator test sketch:
    - L298N: GPIO18 IN1, GPIO19 IN2, GPIO23 ENA
    - One servo only: GPIO25
    - Relay/Pump: GPIO26
    - Limit/E-stop: GPIO27
    - Built-in LED: GPIO2

  Added:
    - UART2 receiver from Sensor ESP32: RX GPIO16, TX GPIO17, 115200.
    - Fast ACK/status frames for dashboard.
    - Non-blocking test buttons and auto tracking.
    - Smart cleaning using the same relay/pump from the test sketch.
*/

#include <Arduino.h>
#include <ESP32Servo.h>
#include <limits.h>

// ================= PINS - EXACTLY FROM TEST CODE =================
const int MOTOR_IN1 = 18;
const int MOTOR_IN2 = 19;
const int MOTOR_ENA = 23;
const int SERVO_PIN = 25;
const int RELAY_PIN = 26;
const int LIMIT_PIN = 27;
const int LED_PIN = 2;
const int UART_RX2 = 16;
const int UART_TX2 = 17;

// ================= SETTINGS - FROM TEST CODE =================
const bool RELAY_ACTIVE_LOW = true;
const int SERVO_MIN_ANGLE = 20;
const int SERVO_MAX_ANGLE = 160;
const int SERVO_CENTER = 90;
const int DOOR_CLOSE_ANGLE = 30;
const int DOOR_OPEN_ANGLE  = 150;
const bool LIMIT_BLOCKS_MOTOR = true;

// ================= TRACKING / SAFETY TUNING =================
const bool START_ARMED = true;
const bool START_AUTO = true;
const bool LDR_HIGHER_RAW_IS_BRIGHTER = true;  // change to false only if your LDR divider is reversed
const bool AZIMUTH_REVERSE = false;
const bool ELEVATION_REVERSE = false;
const int TRACK_LIGHT_MIN_TOTAL = 120;
const int TRACK_ERR_H_DEADBAND = 95;
const int TRACK_ERR_V_DEADBAND = 110;
const int TRACK_MOTOR_PWM_MIN = 95;
const int TRACK_MOTOR_PWM_MAX = 185;
const uint16_t TRACK_MOTOR_PULSE_MS = 90;
const uint16_t TRACK_MOTOR_INTERVAL_MS = 180;
const uint16_t SERVO_STEP_INTERVAL_MS = 260;
const int SERVO_STEP_DEG = 1;
const int OVERCURRENT_MA = 7200;
const uint32_t OVERCURRENT_DELAY_MS = 1200;

// Smart cleaning
const bool START_AUTO_CLEANING = true;
const uint16_t CLEAN_DUST_THRESHOLD_RAW = 1450;
const uint32_t CLEAN_DUST_HOLD_MS = 20000;
const uint32_t CLEAN_RUN_MS = 8000;
const uint32_t CLEAN_COOLDOWN_MS = 30UL * 60UL * 1000UL;

// ================= UART FRAME PROTOCOL =================
static const uint8_t FRAME_START = 0xAA;
static const uint8_t MSG_HELLO   = 0x01;
static const uint8_t MSG_SENSOR  = 0x10;
static const uint8_t MSG_ACK     = 0x11;
static const uint8_t MSG_STATUS  = 0x20;
static const uint8_t MSG_CMD     = 0x30;
static const uint8_t MAX_PAYLOAD = 160;

static const uint16_t SFLAG_DHT_OK       = 1 << 0;
static const uint16_t SFLAG_INA_OK       = 1 << 1;
static const uint16_t SFLAG_DS18B20_OK   = 1 << 2;
static const uint16_t SFLAG_ADC_EXTREME  = 1 << 3;
static const uint16_t SFLAG_RAIN_WET     = 1 << 4;
static const uint16_t SFLAG_PIR1_ACTIVE  = 1 << 5;
static const uint16_t SFLAG_PIR2_ACTIVE  = 1 << 6;
static const uint16_t SFLAG_TILT_ACTIVE  = 1 << 7;

enum CommandId : uint8_t {
  CMD_NONE = 0,
  CMD_ARM = 1,
  CMD_DISARM = 2,
  CMD_AUTO = 3,
  CMD_MANUAL = 4,
  CMD_STOP = 5,
  CMD_MOTOR = 6,
  CMD_SERVO = 7,
  CMD_CENTER = 8,
  CMD_PUMP = 9,
  CMD_CLEAN = 10,
  CMD_ALL_OFF = 11,
  CMD_CLEAN_AUTO = 12
};

#pragma pack(push, 1)
struct SensorPayload {
  uint16_t seq;
  uint32_t uptime_ms;
  uint16_t adcTL;
  uint16_t adcTR;
  uint16_t adcBL;
  uint16_t adcBR;
  int16_t lightErrH;
  int16_t lightErrV;
  uint16_t rainAO;
  uint16_t dustRaw;
  uint8_t rainDO;
  uint8_t pir1;
  uint8_t pir2;
  uint8_t tilt;
  int16_t dsTempC_x100;
  int16_t dhtTempC_x100;
  uint32_t dhtHumidity_x100;
  uint16_t bus_mV;
  int32_t shunt_uV;
  int32_t current_mA;
  uint32_t power_mW;
  uint16_t sensorFlags;
};

struct AckPayload {
  uint16_t seq;
  uint8_t ok;
  uint32_t rxFrames;
  uint32_t lostFrames;
  uint32_t crcFails;
  int16_t motorDuty;
  uint8_t testStage;
};

struct ActuatorStatusPayload {
  uint16_t lastSeq;
  uint32_t uptime_ms;
  uint32_t rxFrames;
  uint32_t lostFrames;
  uint32_t crcFails;
  uint32_t cmdFrames;
  uint8_t linkOK;
  uint8_t armed;
  uint8_t autoMode;
  uint8_t limitActive;
  uint8_t cleaningActive;
  uint8_t pumpOn;
  uint8_t autoCleaning;
  uint8_t testStage;
  int16_t servoDeg;
  int16_t motorDuty;
  int16_t errH_norm;
  int16_t errV_norm;
  uint16_t lightTotal;
  int32_t lastCurrent_mA;
  uint16_t lastSensorFlags;
  uint8_t faultCode;
  uint32_t lastCleanAgo_s;
};

struct CommandPayload {
  uint32_t nonce;
  uint8_t cmd;
  int16_t value;
  uint16_t ms;
};
#pragma pack(pop)

HardwareSerial LinkSerial(2);
Servo servoMotor;
String inputLine = "";

int servoPos = SERVO_CENTER;
int motorValue = 0;
bool relayOn = false;
bool armed = START_ARMED;
bool autoMode = START_AUTO;
bool autoCleaning = START_AUTO_CLEANING;
bool cleaningActive = false;
uint32_t cleaningEndMs = 0;
uint32_t lastCleanMs = 0;
uint32_t dustHighSinceMs = 0;
uint32_t motorPulseEndMs = 0;
uint32_t lastTrackMotorMs = 0;
uint32_t lastServoStepMs = 0;
uint32_t overCurrentSinceMs = 0;
uint8_t faultCode = 0; // 0 none, 1 limit, 2 uart timeout, 3 overcurrent, 4 disarmed, 5 rain

SensorPayload lastSensor{};
bool haveSensor = false;
uint32_t lastSensorMs = 0;
uint32_t rxFrames = 0;
uint32_t cmdFrames = 0;
uint32_t lostFrames = 0;
uint32_t crcFails = 0;
uint32_t badFrames = 0;
uint16_t lastSeq = 0;
uint32_t lastStatusMs = 0;
uint32_t lastCommandNonce = 0;

// ================= Original test functions, kept direct/fast =================
bool limitPressed() { return digitalRead(LIMIT_PIN) == LOW; }

void setRelay(bool on) {
  relayOn = on;
  if (RELAY_ACTIVE_LOW) digitalWrite(RELAY_PIN, on ? LOW : HIGH);
  else digitalWrite(RELAY_PIN, on ? HIGH : LOW);
}

void motorStop() {
  digitalWrite(MOTOR_IN1, LOW);
  digitalWrite(MOTOR_IN2, LOW);
  analogWrite(MOTOR_ENA, 0);
  motorValue = 0;
  motorPulseEndMs = 0;
}

void motorBrake() {
  digitalWrite(MOTOR_IN1, HIGH);
  digitalWrite(MOTOR_IN2, HIGH);
  analogWrite(MOTOR_ENA, 255);
  motorValue = 0;
  motorPulseEndMs = 0;
}

void setMotor(int value) {
  value = constrain(value, -255, 255);
  if (LIMIT_BLOCKS_MOTOR && limitPressed()) {
    faultCode = 1;
    motorStop();
    return;
  }
  if (!armed && value != 0) {
    faultCode = 4;
    motorStop();
    return;
  }
  if (value == 0) {
    motorStop();
    return;
  }
  int duty = abs(value);
  if (value > 0) {
    digitalWrite(MOTOR_IN1, HIGH);
    digitalWrite(MOTOR_IN2, LOW);
  } else {
    digitalWrite(MOTOR_IN1, LOW);
    digitalWrite(MOTOR_IN2, HIGH);
  }
  analogWrite(MOTOR_ENA, duty);
  motorValue = value;
}

void setMotorTimed(int value, uint16_t ms) {
  setMotor(value);
  if (motorValue != 0 && ms > 0) motorPulseEndMs = millis() + ms;
}

void setServoAngle(int angle) {
  angle = constrain(angle, SERVO_MIN_ANGLE, SERVO_MAX_ANGLE);
  servoMotor.write(angle);
  servoPos = angle;
}

void allOff() {
  motorStop();
  setRelay(false);
  setServoAngle(SERVO_CENTER);
  cleaningActive = false;
  digitalWrite(LED_PIN, LOW);
}

// ================= CRC / Frames =================
uint8_t crc8MaximUpdate(uint8_t crc, uint8_t data) {
  crc ^= data;
  for (uint8_t i = 0; i < 8; i++) crc = (crc & 0x01) ? (crc >> 1) ^ 0x8C : (crc >> 1);
  return crc;
}

void sendFrame(Stream &s, uint8_t msgId, const uint8_t *payload, uint8_t payloadLen) {
  uint8_t len = payloadLen + 1;
  uint8_t crc = 0;
  s.write(FRAME_START);
  s.write(len);
  crc = crc8MaximUpdate(crc, len);
  s.write(msgId);
  crc = crc8MaximUpdate(crc, msgId);
  for (uint8_t i = 0; i < payloadLen; i++) {
    s.write(payload[i]);
    crc = crc8MaximUpdate(crc, payload[i]);
  }
  s.write(crc);
}

bool readFrame(Stream &s, uint8_t &msgId, uint8_t *payload, uint8_t &payloadLen) {
  static enum { WAIT_START, READ_LEN, READ_BODY, READ_CRC } state = WAIT_START;
  static uint8_t len = 0;
  static uint8_t body[MAX_PAYLOAD + 1];
  static uint8_t idx = 0;
  static uint8_t crc = 0;
  while (s.available()) {
    uint8_t b = (uint8_t)s.read();
    switch (state) {
      case WAIT_START:
        if (b == FRAME_START) state = READ_LEN;
        break;
      case READ_LEN:
        len = b;
        if (len < 1 || len > MAX_PAYLOAD + 1) { badFrames++; state = WAIT_START; }
        else { idx = 0; crc = crc8MaximUpdate(0, len); state = READ_BODY; }
        break;
      case READ_BODY:
        body[idx++] = b;
        crc = crc8MaximUpdate(crc, b);
        if (idx >= len) state = READ_CRC;
        break;
      case READ_CRC:
        if (b == crc) {
          msgId = body[0];
          payloadLen = len - 1;
          if (payloadLen) memcpy(payload, &body[1], payloadLen);
          state = WAIT_START;
          return true;
        } else { crcFails++; state = WAIT_START; }
        break;
    }
  }
  return false;
}

void sendAck(uint16_t seq) {
  AckPayload a{};
  a.seq = seq;
  a.ok = 1;
  a.rxFrames = rxFrames;
  a.lostFrames = lostFrames;
  a.crcFails = crcFails;
  a.motorDuty = motorValue;
  a.testStage = 0;
  sendFrame(LinkSerial, MSG_ACK, (const uint8_t *)&a, sizeof(a));
}

int16_t normErrH(const SensorPayload &p) {
  int32_t e = p.lightErrH;
  if (!LDR_HIGHER_RAW_IS_BRIGHTER) e = -e;
  if (AZIMUTH_REVERSE) e = -e;
  return (int16_t)constrain(e, -30000, 30000);
}

int16_t normErrV(const SensorPayload &p) {
  int32_t e = p.lightErrV;
  if (!LDR_HIGHER_RAW_IS_BRIGHTER) e = -e;
  if (ELEVATION_REVERSE) e = -e;
  return (int16_t)constrain(e, -30000, 30000);
}

uint16_t lightTotal(const SensorPayload &p) {
  uint32_t t = (uint32_t)p.adcTL + p.adcTR + p.adcBL + p.adcBR;
  if (t > 65535) t = 65535;
  return (uint16_t)t;
}

void sendStatus() {
  ActuatorStatusPayload s{};
  s.lastSeq = lastSeq;
  s.uptime_ms = millis();
  s.rxFrames = rxFrames;
  s.lostFrames = lostFrames;
  s.crcFails = crcFails;
  s.cmdFrames = cmdFrames;
  s.linkOK = (haveSensor && millis() - lastSensorMs < 2500) ? 1 : 0;
  s.armed = armed ? 1 : 0;
  s.autoMode = autoMode ? 1 : 0;
  s.limitActive = limitPressed() ? 1 : 0;
  s.cleaningActive = cleaningActive ? 1 : 0;
  s.pumpOn = relayOn ? 1 : 0;
  s.autoCleaning = autoCleaning ? 1 : 0;
  s.testStage = 0;
  s.servoDeg = servoPos;
  s.motorDuty = motorValue;
  s.errH_norm = haveSensor ? normErrH(lastSensor) : 0;
  s.errV_norm = haveSensor ? normErrV(lastSensor) : 0;
  s.lightTotal = haveSensor ? lightTotal(lastSensor) : 0;
  s.lastCurrent_mA = haveSensor ? lastSensor.current_mA : 0;
  s.lastSensorFlags = haveSensor ? lastSensor.sensorFlags : 0;
  s.faultCode = faultCode;
  s.lastCleanAgo_s = lastCleanMs ? (millis() - lastCleanMs) / 1000UL : 0xFFFFFFFFUL;
  sendFrame(LinkSerial, MSG_STATUS, (const uint8_t *)&s, sizeof(s));
}

void startCleaning(uint16_t ms) {
  if (!armed) { faultCode = 4; return; }
  if (lastSensor.sensorFlags & SFLAG_RAIN_WET) { faultCode = 5; return; }
  cleaningActive = true;
  cleaningEndMs = millis() + (ms ? ms : CLEAN_RUN_MS);
  setRelay(true);
  lastCleanMs = millis();
}

void stopCleaning() {
  cleaningActive = false;
  cleaningEndMs = 0;
  setRelay(false);
}

void handleCommand(const CommandPayload &c) {
  // Repeated commands with the same nonce are accepted only once.
  if (c.nonce == lastCommandNonce) return;
  lastCommandNonce = c.nonce;
  cmdFrames++;
  faultCode = 0;

  switch (c.cmd) {
    case CMD_ARM: armed = true; break;
    case CMD_DISARM: armed = false; motorStop(); stopCleaning(); break;
    case CMD_AUTO: autoMode = true; armed = true; break;
    case CMD_MANUAL: autoMode = false; break;
    case CMD_STOP: motorStop(); break;
    case CMD_ALL_OFF: allOff(); break;
    case CMD_MOTOR: autoMode = false; setMotorTimed(c.value, c.ms ? c.ms : 500); break;
    case CMD_SERVO: autoMode = false; setServoAngle(c.value); break;
    case CMD_CENTER: setServoAngle(SERVO_CENTER); break;
    case CMD_PUMP: setRelay(c.value != 0); cleaningActive = (c.value != 0); cleaningEndMs = (c.value != 0 && c.ms) ? millis() + c.ms : 0; break;
    case CMD_CLEAN: startCleaning(c.ms ? c.ms : CLEAN_RUN_MS); break;
    case CMD_CLEAN_AUTO: autoCleaning = (c.value != 0); break;
    default: break;
  }
  sendStatus(); // immediate feedback: dashboard feels fast
}

void handleIncomingUart() {
  uint8_t msgId, len;
  uint8_t payload[MAX_PAYLOAD];
  while (readFrame(LinkSerial, msgId, payload, len)) {
    if (msgId == MSG_SENSOR && len == sizeof(SensorPayload)) {
      SensorPayload p;
      memcpy(&p, payload, sizeof(p));
      if (haveSensor && (uint16_t)(p.seq - lastSeq) > 1) lostFrames += (uint16_t)(p.seq - lastSeq - 1);
      lastSensor = p;
      haveSensor = true;
      lastSensorMs = millis();
      lastSeq = p.seq;
      rxFrames++;
      sendAck(p.seq);
    } else if (msgId == MSG_CMD && len == sizeof(CommandPayload)) {
      CommandPayload c;
      memcpy(&c, payload, sizeof(c));
      handleCommand(c);
    } else {
      badFrames++;
    }
  }
}

// ================= Tracking / cleaning / safety =================
void updateTimedOutputs() {
  uint32_t now = millis();
  if (motorPulseEndMs && (int32_t)(now - motorPulseEndMs) >= 0) motorStop();
  if (cleaningActive && cleaningEndMs && (int32_t)(now - cleaningEndMs) >= 0) stopCleaning();
}

void updateSafety() {
  if (limitPressed()) {
    digitalWrite(LED_PIN, millis() % 300 < 150 ? HIGH : LOW);
    if (LIMIT_BLOCKS_MOTOR && motorValue != 0) motorStop();
    if (faultCode == 0) faultCode = 1;
  } else {
    digitalWrite(LED_PIN, (haveSensor && millis() - lastSensorMs < 2500) ? HIGH : LOW);
  }

  if (haveSensor && (lastSensor.sensorFlags & SFLAG_INA_OK) && abs(lastSensor.current_mA) > OVERCURRENT_MA) {
    if (!overCurrentSinceMs) overCurrentSinceMs = millis();
    if (millis() - overCurrentSinceMs > OVERCURRENT_DELAY_MS) {
      motorStop();
      stopCleaning();
      faultCode = 3;
    }
  } else {
    overCurrentSinceMs = 0;
  }

  if (!haveSensor || millis() - lastSensorMs > 3000) {
    if (motorValue != 0) motorStop();
    if (faultCode == 0) faultCode = 2;
  }
}

void updateAutoTracking() {
  if (!armed || !autoMode || !haveSensor) return;
  uint32_t now = millis();
  if (now - lastSensorMs > 2500) return;
  if (limitPressed()) return;
  if (lastSensor.sensorFlags & SFLAG_RAIN_WET) { motorStop(); faultCode = 5; return; }

  uint16_t total = lightTotal(lastSensor);
  if (total < TRACK_LIGHT_MIN_TOTAL) { motorStop(); return; }

  int16_t eh = normErrH(lastSensor);
  int16_t ev = normErrV(lastSensor);

  if (now - lastTrackMotorMs >= TRACK_MOTOR_INTERVAL_MS && motorValue == 0) {
    lastTrackMotorMs = now;
    if (abs(eh) > TRACK_ERR_H_DEADBAND) {
      int duty = map(constrain(abs(eh), TRACK_ERR_H_DEADBAND, 2500), TRACK_ERR_H_DEADBAND, 2500, TRACK_MOTOR_PWM_MIN, TRACK_MOTOR_PWM_MAX);
      if (eh < 0) duty = -duty;
      setMotorTimed(duty, TRACK_MOTOR_PULSE_MS);
    }
  }

  if (now - lastServoStepMs >= SERVO_STEP_INTERVAL_MS) {
    lastServoStepMs = now;
    if (abs(ev) > TRACK_ERR_V_DEADBAND) {
      int next = servoPos + ((ev > 0) ? SERVO_STEP_DEG : -SERVO_STEP_DEG);
      setServoAngle(next);
    }
  }
}

void updateAutoCleaning() {
  if (!autoCleaning || !armed || !haveSensor) return;
  uint32_t now = millis();
  if (cleaningActive) return;
  if (lastSensor.sensorFlags & SFLAG_RAIN_WET) { dustHighSinceMs = 0; return; }
  if (lastCleanMs && now - lastCleanMs < CLEAN_COOLDOWN_MS) return;

  if (lastSensor.dustRaw >= CLEAN_DUST_THRESHOLD_RAW) {
    if (!dustHighSinceMs) dustHighSinceMs = now;
    if (now - dustHighSinceMs >= CLEAN_DUST_HOLD_MS) {
      startCleaning(CLEAN_RUN_MS);
      dustHighSinceMs = 0;
    }
  } else {
    dustHighSinceMs = 0;
  }
}

// ================= Serial manual test kept from original, with compact commands =================
void printStatus() {
  Serial.println();
  Serial.println("========== ACTUATOR STATUS ==========");
  Serial.print("Motor = "); Serial.println(motorValue);
  Serial.print("Servo = "); Serial.println(servoPos);
  Serial.print("Relay/Pump = "); Serial.println(relayOn ? "ON" : "OFF");
  Serial.print("Limit/E-stop = "); Serial.println(limitPressed() ? "PRESSED" : "NOT PRESSED");
  Serial.print("UART sensor link = "); Serial.println((haveSensor && millis() - lastSensorMs < 2500) ? "OK" : "WAITING/TIMEOUT");
  Serial.print("ARM/AUTO = "); Serial.print(armed); Serial.print('/'); Serial.println(autoMode);
  Serial.print("rx/cmd/lost/crc = "); Serial.print(rxFrames); Serial.print('/'); Serial.print(cmdFrames); Serial.print('/'); Serial.print(lostFrames); Serial.print('/'); Serial.println(crcFails);
  Serial.println("=====================================");
  Serial.println();
}

void printHelp() {
  Serial.println();
  Serial.println("========== ESP32 ACTUATOR TEST-BASE FAST UART ==========");
  Serial.println("Serial commands still work:");
  Serial.println("  arm | disarm | auto | manual | status | alloff");
  Serial.println("  motor f 120 | motor r 120 | motor 150 | motor -150 | stop | brake");
  Serial.println("  servo 90 | center | door open | door close");
  Serial.println("  relay on/off | pump on/off | clean");
  Serial.println("UART2: RX GPIO16, TX GPIO17, 115200");
  Serial.println("========================================================");
  Serial.println();
}

void handleSerialCommand(String cmd) {
  cmd.trim();
  cmd.toLowerCase();
  if (cmd.length() == 0) return;
  if (cmd == "help") printHelp();
  else if (cmd == "status") printStatus();
  else if (cmd == "arm") { armed = true; Serial.println("ARMED"); }
  else if (cmd == "disarm") { armed = false; motorStop(); stopCleaning(); Serial.println("DISARMED"); }
  else if (cmd == "auto") { autoMode = true; armed = true; Serial.println("AUTO tracking ON"); }
  else if (cmd == "manual") { autoMode = false; Serial.println("MANUAL"); }
  else if (cmd == "alloff") { allOff(); Serial.println("ALL OFF"); }
  else if (cmd == "stop" || cmd == "motor stop") { motorStop(); Serial.println("Motor stopped"); }
  else if (cmd == "brake") { motorBrake(); Serial.println("Motor brake"); }
  else if (cmd.startsWith("motor f")) { int duty = cmd.substring(7).toInt(); if (duty <= 0) duty = 120; setMotorTimed(duty, 700); Serial.println("Motor forward"); }
  else if (cmd.startsWith("motor r")) { int duty = cmd.substring(7).toInt(); if (duty <= 0) duty = 120; setMotorTimed(-duty, 700); Serial.println("Motor reverse"); }
  else if (cmd.startsWith("motor ")) { setMotorTimed(cmd.substring(6).toInt(), 700); Serial.println("Motor signed"); }
  else if (cmd.startsWith("servo ")) { setServoAngle(cmd.substring(6).toInt()); Serial.println("Servo moved"); }
  else if (cmd == "center") { setServoAngle(SERVO_CENTER); Serial.println("Servo center"); }
  else if (cmd == "door open") { setServoAngle(DOOR_OPEN_ANGLE); Serial.println("Door open"); }
  else if (cmd == "door close") { setServoAngle(DOOR_CLOSE_ANGLE); Serial.println("Door close"); }
  else if (cmd == "relay on" || cmd == "pump on") { setRelay(true); Serial.println("Relay/Pump ON"); }
  else if (cmd == "relay off" || cmd == "pump off") { setRelay(false); cleaningActive = false; Serial.println("Relay/Pump OFF"); }
  else if (cmd == "clean") { startCleaning(CLEAN_RUN_MS); Serial.println("Cleaning started"); }
  else Serial.println("Unknown command. Type help");
}

void handleSerialInput() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (inputLine.length() > 0) { handleSerialCommand(inputLine); inputLine = ""; }
    } else inputLine += c;
  }
}

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(MOTOR_IN1, OUTPUT);
  pinMode(MOTOR_IN2, OUTPUT);
  pinMode(MOTOR_ENA, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(LIMIT_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);

  servoMotor.attach(SERVO_PIN);
  motorStop();
  setRelay(false);
  setServoAngle(SERVO_CENTER);

  LinkSerial.begin(115200, SERIAL_8N1, UART_RX2, UART_TX2);

  Serial.println();
  Serial.println("ESP32 Actuator Test-Base FastUART Ready");
  Serial.println("Pins are identical to your working actuator test sketch.");
  Serial.println("Servo GPIO25, Relay/Pump GPIO26, L298N GPIO18/19/23");
  printHelp();
}

void loop() {
  handleSerialInput();
  handleIncomingUart();
  updateTimedOutputs();
  updateSafety();
  updateAutoTracking();
  updateAutoCleaning();

  uint32_t now = millis();
  if (now - lastStatusMs >= 150) {
    lastStatusMs = now;
    sendStatus();
  }
}
